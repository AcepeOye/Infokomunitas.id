import React, { useState, useMemo, useEffect } from "react";
import {
  Search, Flame, Calendar, MapPin, ShoppingBag, Users, Star,
  Clock, ChevronRight, X, Menu, TrendingUp, ArrowUpRight,
  Car, Sprout, Fish, Bird, Bug, Waves, Cat, Dog,
  LayoutDashboard, FileText, CalendarDays, Store, Settings2,
  Plus, Edit3, Trash2, LogOut, Eye, BarChart3, Activity, User, Lock
} from "lucide-react";

// ===== TYPES =====
type Article = { id:number; cat:string; title:string; excerpt:string; img:string; time:string; views:string; tag?:string; komunitas?:string; rubrik?:string; status?:string; content?:string };
type EventItem = { id:number; title:string; date:string; loc:string; komunitas:string; countdown:string; img:string; desc?:string; price?:string };
type Product = { id:number; name:string; price:string; sold:string; loc:string; img:string; cat:string; seller?:string; stock?:string; desc?:string };
type KomunitasCat = { name:string; icon:any; color:string; count:string };
type KomunitasData = { id:number; name:string; category:string; members:string; location:string; desc:string; iconName?:string; status?:string };

const kategoriKomunitas: KomunitasCat[] = [
  { name:"Otomotif", icon: Car, color:"bg-blue-100 text-blue-600", count:"1.2k komunitas" },
  { name:"Tanaman", icon: Sprout, color:"bg-green-100 text-green-600", count:"892 komunitas" },
  { name:"Ikan Hias", icon: Fish, color:"bg-cyan-100 text-cyan-600", count:"654 komunitas" },
  { name:"Ayam Hias", icon: Bird, color:"bg-amber-100 text-amber-600", count:"521 komunitas" },
  { name:"Burung", icon: Bird, color:"bg-sky-100 text-sky-600", count:"1.1k komunitas" },
  { name:"Reptil", icon: Bug, color:"bg-lime-100 text-lime-600", count:"312 komunitas" },
  { name:"Aquascape", icon: Waves, color:"bg-teal-100 text-teal-600", count:"445 komunitas" },
  { name:"Kucing", icon: Cat, color:"bg-orange-100 text-orange-600", count:"978 komunitas" },
  { name:"Anjing", icon: Dog, color:"bg-zinc-100 text-zinc-600", count:"412 komunitas" },
  { name:"Mancing", icon: Fish, color:"bg-indigo-100 text-indigo-600", count:"733 komunitas" },
];

const heroFeatured: Article = {
  id:1,
  cat:"OTOMOTIF",
  title:"Kontes Modifikasi Akbar 2025: 800 Mobil Tumpah Ruah di Senayan, Komunitas JDM Dominasi Podium",
  excerpt:"Gelaran tahunan paling ditunggu anak otomotif. Dari stance culture sampai restomod, semua kumpul. Juri asal Jepang kasih standing ovation untuk karya anak Bandung.",
  img:"https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=800&q=80",
  time:"2 jam lalu",
  views:"12.4k",
  tag:"HOT",
  komunitas:"JDM Enthusiast ID",
  rubrik:"News",
  status:"Published"
};

const heroSide: Article[] = [
  { id:2, cat:"TANAMAN", title:"Harga Monstera Variegata Anjlok 70%? Petani Tanaman Hias Buka Suara", excerpt:"", img:"https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=300&q=80", time:"4 jam lalu", views:"8.1k", komunitas:"Tanaman Hias Nusantara", rubrik:"News", status:"Published"},
  { id:3, cat:"BISNIS", title:"Omzet Rp 300 Juta/Bulan dari Budidaya Cupang: Kisah Farm di Bekasi", excerpt:"", img:"https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=300&q=80", time:"5 jam lalu", views:"5.3k", komunitas:"Betta Lovers", rubrik:"Bisnis", status:"Published"},
  { id:4, cat:"AYAM", title:"Ayam Ketawa Asli Sidenreng Pemenang Kontes Suara Harganya Tembus 45 Juta", excerpt:"", img:"https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?w=300&q=80", time:"6 jam lalu", views:"9.2k", komunitas:"Ayam Ketawa Indonesia", rubrik:"Hobi", status:"Published"},
  { id:5, cat:"BURUNG", title:"Kicaumania Jakarta Siap Gelar Piala Presiden: Total Hadiah 1,2 Miliar", excerpt:"", img:"https://images.unsplash.com/photo-1452570053594-1b985d6ea890?w=300&q=80", time:"8 jam lalu", views:"6.7k", komunitas:"Kicaumania", rubrik:"News", status:"Published"},
];

const newsGrid: Article[] = [
  { id:10, cat:"News", title:"Komunitas Vespa Gelar Touring 1000KM Jawa-Bali: 250 Rider Gas Pol", excerpt:"Touring amal sambil baksos di 5 kota, total donasi 120 juta terkumpul", img:"https://images.unsplash.com/photo-1558981852-426c6c22a060?w=400&q=80", time:"1 jam lalu", views:"3.2k", rubrik:"News", status:"Published" },
  { id:11, cat:"News", title:"Aquascape Contest Indonesia Pecahkan Rekor: 1.500 Tank Daftar", excerpt:"Juri dari ADA Jepang datang langsung, karya anak Jogja masuk top 3 dunia", img:"https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=400&q=80", time:"3 jam lalu", views:"4.1k", rubrik:"News", status:"Published" },
  { id:12, cat:"News", title:"Komunitas Kucing Rescue 30 Kucing Terlantar di Jakarta Utara", excerpt:"Aksi cepat tanggap Animal Defender, semua kucing sudah diadopsi", img:"https://images.unsplash.com/photo-1514888286974-6c03e2ca1d76?w=400&q=80", time:"4 jam lalu", views:"2.8k", rubrik:"News", status:"Published" },
  { id:13, cat:"News", title:"Dramatik! Komunitas Layangan Bali Juara Festival Internasional di Dieppe", excerpt:"Layangan Naga 100 Meter buatan Gianyar curi perhatian dunia", img:"https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=400&q=80", time:"6 jam lalu", views:"5k", rubrik:"News", status:"Published" },
  { id:14, cat:"News", title:"Reptil Expo Surabaya: Python Reticulatus Albino Jadi Bintang", excerpt:"Panjang 5 meter, harga 85 juta masih ditawar kolektor Jakarta", img:"https://images.unsplash.com/photo-1474511320723-9a56873867b5?w=400&q=80", time:"7 jam lalu", views:"3.9k", rubrik:"News", status:"Published" },
  { id:15, cat:"News", title:"Komunitas Sepeda Lipat Gowes Sambil Bersih-Bersih Sungai Ciliwung", excerpt:"150 Seli-ist kumpulkan 2 ton sampah dalam 3 jam", img:"https://images.unsplash.com/photo-1571068316344-75bc76f77890?w=400&q=80", time:"9 jam lalu", views:"2.1k", rubrik:"News", status:"Published" },
];

const bisnisList: Article[] = [
  { id:20, cat:"Bisnis", title:"Supplier Pakan Ayam Bangkok Premium: Omzet Naik 200% Lewat Grup FB", excerpt:"Testimoni peternak: ayam lebih agresif dan bulu mengkilap", img:"https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=200&q=80", time:"2 jam lalu", views:"1.2k", komunitas:"Juragan Pakan", rubrik:"Bisnis", status:"Published" },
  { id:21, cat:"Bisnis", title:"Jasa Grooming Kucing Panggilan Jakarta: 30 Pelanggan/Hari, Full Booking!", excerpt:"Modal 5 juta, sekarang punya 4 cabang", img:"https://images.unsplash.com/photo-1514888286974-6c03e2ca1d76?w=200&q=80", time:"5 jam lalu", views:"980", komunitas:"Meow Grooming", rubrik:"Bisnis", status:"Published" },
  { id:22, cat:"Bisnis", title:"Bengkel Custom Trail Jadul di Bandung Kebanjiran Order dari Luar Negeri", excerpt:"Garapan tracker dan scrambler dikirim sampai ke Australia", img:"https://images.unsplash.com/photo-1558981852-426c6c22a060?w=200&q=80", time:"1 hari lalu", views:"2.3k", komunitas:"Custom Culture", rubrik:"Bisnis", status:"Published" },
  { id:23, cat:"Bisnis", title:"Bibit Tanaman Hias Impor Thailand Masuk Lewat Komunitas, Harga Lebih Murah 40%", excerpt:"Jalur komunitas lebih trusted daripada marketplace", img:"https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=200&q=80", time:"1 hari lalu", views:"1.8k", komunitas:"Importir Tanaman", rubrik:"Bisnis", status:"Published" },
];

const hobiData: Record<string, Article[]> = {
  Otomotif: [
    { id:30, cat:"Otomotif", title:"Tips Setting Karbu PE28 Biar Irit Tapi Tetap Ngacir", excerpt:"", img:"https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=400", time:"Baru", views:"1k", rubrik:"Hobi", status:"Published"},
    { id:31, cat:"Otomotif", title:"Komunitas CB Klasik Touring Napak Tilas Jalur Selatan Jawa", excerpt:"", img:"https://images.unsplash.com/photo-1558981852-426c6c22a060?w=400", time:"2 jam", views:"890", rubrik:"Hobi", status:"Published"},
    { id:32, cat:"Otomotif", title:"Review Oli Sesat yang Lagi Viral di Grup Matic", excerpt:"", img:"https://images.unsplash.com/photo-1486262715619-67b85e568840?w=400", time:"5 jam", views:"1.2k", rubrik:"Hobi", status:"Published"},
  ],
  Tanaman: [
    { id:33, cat:"Tanaman", title:"Cara Selamatkan Monstera Busuk Akar di Musim Hujan", excerpt:"", img:"https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400", time:"Baru", views:"2k", rubrik:"Hobi", status:"Published"},
    { id:34, cat:"Tanaman", title:"Rahasia Media Tanam Aglo Biar Daunnya Makin Ngejreng", excerpt:"", img:"https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=400", time:"3 jam", views:"1.5k", rubrik:"Hobi", status:"Published"},
    { id:35, cat:"Tanaman", title:"Komunitas Aroid Bekasi Bagi-bagi Anakan Gratis Tiap Minggu", excerpt:"", img:"https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400", time:"6 jam", views:"980", rubrik:"Hobi", status:"Published"},
  ],
  Ikan: [
    { id:36, cat:"Ikan", title:"Treatment Kutu Jarum pada Arwana Golden Red", excerpt:"", img:"https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=400", time:"Baru", views:"1.1k", rubrik:"Hobi", status:"Published"},
    { id:37, cat:"Ikan", title:"Pakan Racikan Biar Warna Louhan Makin Pecah", excerpt:"", img:"https://images.unsplash.com/photo-1535591273668-578e31182c4f?w=400", time:"4 jam", views:"2k", rubrik:"Hobi", status:"Published"},
    { id:38, cat:"Ikan", title:"Kontes Channa Maru di Depok: Juara Umum Bawa Pulang 15 Juta", excerpt:"", img:"https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=400", time:"8 jam", views:"1.3k", rubrik:"Hobi", status:"Published"},
  ],
  Ayam: [
    { id:39, cat:"Ayam", title:"Jamu Tradisional Biar Ayam Bangkok Gak Ngorok", excerpt:"", img:"https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?w=400", time:"Baru", views:"900", rubrik:"Hobi", status:"Published"},
    { id:40, cat:"Ayam", title:"Kandang Umbaran vs Box: Mana Lebih Baik untuk Ayam Kontes?", excerpt:"", img:"https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?w=400", time:"3 jam", views:"1.2k", rubrik:"Hobi", status:"Published"},
    { id:41, cat:"Ayam", title:"Daftar Harga Ayam Pelung Jawara Bulan Ini", excerpt:"", img:"https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?w=400", time:"5 jam", views:"1.8k", rubrik:"Hobi", status:"Published"},
  ],
};

const tipsList: Article[] = [
  { id:50, cat:"Tips", title:"5 Kesalahan Fatal Pemula Pelihara Iguana", excerpt:"Sering dianggap gampang, tapi banyak yang mati di bulan pertama karena ini", img:"https://images.unsplash.com/photo-1474511320723-9a56873867b5?w=400", time:"Tips", views:"", rubrik:"Tips", status:"Published" },
  { id:51, cat:"Tips", title:"Cara Bedakan Burung Murai Batu Ori Medan vs Silangan", excerpt:"Jangan sampai ketipu harga 10 juta tapi ternyata silangan Borneo", img:"https://images.unsplash.com/photo-1452570053594-1b985d6ea890?w=400", time:"Tips", views:"", rubrik:"Tips", status:"Published" },
  { id:52, cat:"Tips", title:"Setting Aquascape Low Budget 500 Ribu Jadi Mewah", excerpt:"Trik pakai tanaman low co2 tapi tetap rimbun dan estetik", img:"https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=400", time:"Tips", views:"", rubrik:"Tips", status:"Published" },
  { id:53, cat:"Tips", title:"Modifikasi Motor Harian Biar Lolos Razia Polisi", excerpt:"Part yang aman dan tetap stylish, anti tilang", img:"https://images.unsplash.com/photo-1558981852-426c6c22a060?w=400", time:"Tips", views:"", rubrik:"Tips", status:"Published" },
];

const eventsSeed: EventItem[] = [
  { id:1, title:"Jakarta Auto Meetup & Contest", date:"15 Des 2025", loc:"Parkir Timur Senayan", komunitas:"Otomotif", countdown:"3 HARI LAGI", img:"https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=200", desc:"Kontes modifikasi terbesar", price:"Rp 50.000" },
  { id:2, title:"Flora & Fauna Expo BSD", date:"20-22 Des 2025", loc:"ICE BSD City", komunitas:"Tanaman & Hewan", countdown:"8 HARI LAGI", img:"https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=200", desc:"Pameran tanaman hias", price:"Rp 25.000" },
  { id:3, title:"Piala Kicau Nusantara", date:"21 Des 2025", loc:"Lap. Banteng, Jakarta", komunitas:"Burung", countdown:"9 HARI LAGI", img:"https://images.unsplash.com/photo-1452570053594-1b985d6ea890?w=200", desc:"Lomba kicau hadiah 1,2M", price:"Rp 150.000" },
  { id:4, title:"Channa Contest Jabodetabek", date:"28 Des 2025", loc:"Mall Ciputra Cibubur", komunitas:"Ikan", countdown:"16 HARI LAGI", img:"https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=200", desc:"Kontes Channa Maru", price:"Rp 75.000" },
  { id:5, title:"Cat Lovers Gathering Year End", date:"29 Des 2025", loc:"Tebet Eco Park", komunitas:"Kucing", countdown:"17 HARI LAGI", img:"https://images.unsplash.com/photo-1514888286974-6c03e2ca1d76?w=200", desc:"Kumpul komunitas kucing", price:"Gratis" },
];

const lapakSeed: Product[] = [
  { id:1, name:"Bibit Monstera Thai Constellation", price:"Rp 125.000", sold:"Terjual 320", loc:"Bogor", img:"https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=300", cat:"Tanaman", seller:"Kebun Sultan", stock:"120" },
  { id:2, name:"Pakan Ayam Bangkok Super Fighter 1kg", price:"Rp 45.000", sold:"Terjual 1.2k", loc:"Sidoarjo", img:"https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=300", cat:"Ayam", seller:"Juragan Pakan", stock:"500" },
  { id:3, name:"Knalpot Racing CB150 Old Full System", price:"Rp 890.000", sold:"Terjual 87", loc:"Bandung", img:"https://images.unsplash.com/photo-1558981852-426c6c22a060?w=300", cat:"Otomotif", seller:"Custom Parts BDG", stock:"12" },
  { id:4, name:"Aquascape Stone Dragon Rock 5kg", price:"Rp 75.000", sold:"Terjual 540", loc:"Malang", img:"https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=300", cat:"Aquascape", seller:"Aqua Malang", stock:"80" },
  { id:5, name:"Pelet Louhan Colour Up 100gr", price:"Rp 35.000", sold:"Terjual 2.1k", loc:"Jakarta", img:"https://images.unsplash.com/photo-1535591273668-578e31182c4f?w=300", cat:"Ikan", seller:"Fish Food JKT", stock:"300" },
  { id:6, name:"Sangkar Murai Batu Ukir Jepara", price:"Rp 1.250.000", sold:"Terjual 42", loc:"Jepara", img:"https://images.unsplash.com/photo-1452570053594-1b985d6ea890?w=300", cat:"Burung", seller:"Jepara Craft", stock:"15" },
  { id:7, name:"Lampu Aquascape Chihiros WRGB II", price:"Rp 1.850.000", sold:"Terjual 112", loc:"Surabaya", img:"https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=300", cat:"Aquascape", seller:"Aqua SBY", stock:"20" },
  { id:8, name:"Kaos Komunitas Kucing 'Anabul Sultan'", price:"Rp 89.000", sold:"Terjual 890", loc:"Yogyakarta", img:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300", cat:"Merchandise", seller:"Meow Merch", stock:"200" },
];

const komunitasSeed: KomunitasData[] = [
  { id:1, name:"JDM Enthusiast ID", category:"Otomotif", members:"1.2k", location:"Jakarta", desc:"Komunitas pecinta JDM", status:"Aktif" },
  { id:2, name:"Tanaman Hias Nusantara", category:"Tanaman", members:"892", location:"Bogor", desc:"Kolektor tanaman hias", status:"Aktif" },
  { id:3, name:"Betta Lovers Indonesia", category:"Ikan Hias", members:"654", location:"Bekasi", desc:"Cupang hias", status:"Aktif" },
  { id:4, name:"Kicaumania Jakarta", category:"Burung", members:"1.1k", location:"Jakarta", desc:"Kicau mania", status:"Aktif" },
];

const trending = [
  { rank:1, title:"Viral! Emak-Emak Komunitas Tanaman Hias Borong 200 Pot di Lembang", views:"24k" },
  { rank:2, title:"Harga Ayam Cemani Lidah Hitam Tembus 15 Juta Per Ekor", views:"19k" },
  { rank:3, title:"Modifikasi Motor Listrik Gesits Jadi Cafe Racer Pertama di Indonesia", views:"17k" },
  { rank:4, title:"Kontes Kucing Persia: Kucing Kampung Menang Best in Show!", views:"15k" },
  { rank:5, title:"Panen Raya Cupang Halfmoon di Cirebon, Ekspor ke Eropa", views:"12k" },
];

const LS_KEYS = {
  articles: "infokomunitas_articles",
  events: "infokomunitas_events",
  lapak: "infokomunitas_lapak",
  komunitas: "infokomunitas_komunitas",
  adminLogged: "infokomunitas_admin_logged"
};

export default function App() {
  // Mode Website vs Admin
  const [mode, setMode] = useState<'website'|'admin'>('website');
  const [adminLogged, setAdminLogged] = useState(false);
  const [adminPage, setAdminPage] = useState('Dashboard');
  const [adminMobileOpen, setAdminMobileOpen] = useState(false);

  // Website states
  const [search, setSearch] = useState("");
  const [activeHobi, setActiveHobi] = useState("Otomotif");
  const [selected, setSelected] = useState<Article | null>(null);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [activeNav, setActiveNav] = useState("News");

  // CMS Data - load from localStorage
  const [customArticles, setCustomArticles] = useState<Article[]>(() => {
    try { const v = localStorage.getItem(LS_KEYS.articles); return v ? JSON.parse(v) : []; } catch { return []; }
  });
  const [customEvents, setCustomEvents] = useState<EventItem[]>(() => {
    try { const v = localStorage.getItem(LS_KEYS.events); return v ? JSON.parse(v) : []; } catch { return []; }
  });
  const [customLapak, setCustomLapak] = useState<Product[]>(() => {
    try { const v = localStorage.getItem(LS_KEYS.lapak); return v ? JSON.parse(v) : []; } catch { return []; }
  });
  const [customKomunitas, setCustomKomunitas] = useState<KomunitasData[]>(() => {
    try { const v = localStorage.getItem(LS_KEYS.komunitas); return v ? JSON.parse(v) : []; } catch { return []; }
  });

  // Load admin logged
  useEffect(() => {
    try { if (localStorage.getItem(LS_KEYS.adminLogged) === 'true') setAdminLogged(true); } catch {}
  }, []);

  // Persist
  useEffect(() => { try { localStorage.setItem(LS_KEYS.articles, JSON.stringify(customArticles)); } catch {} }, [customArticles]);
  useEffect(() => { try { localStorage.setItem(LS_KEYS.events, JSON.stringify(customEvents)); } catch {} }, [customEvents]);
  useEffect(() => { try { localStorage.setItem(LS_KEYS.lapak, JSON.stringify(customLapak)); } catch {} }, [customLapak]);
  useEffect(() => { try { localStorage.setItem(LS_KEYS.komunitas, JSON.stringify(customKomunitas)); } catch {} }, [customKomunitas]);

  // Login
  const [loginForm, setLoginForm] = useState({ user:'', pass:'' });
  const [loginError, setLoginError] = useState('');
  const handleLogin = () => {
    if (loginForm.user==='admin' && loginForm.pass==='admin') {
      setAdminLogged(true);
      try { localStorage.setItem(LS_KEYS.adminLogged, 'true'); } catch {}
      setLoginError('');
      setAdminPage('Dashboard');
    } else {
      setLoginError('Username / password salah. Gunakan admin / admin');
    }
  };
  const handleLogout = () => {
    setAdminLogged(false);
    try { localStorage.removeItem(LS_KEYS.adminLogged); } catch {}
    setMode('website');
  };

  // Combined data for website
  const combinedNews = useMemo(() => {
    const customs = customArticles.filter(a => (a.rubrik||'News').toLowerCase()==='news' || !a.rubrik);
    const all = [...customs, ...newsGrid];
    if (!search) return all;
    return all.filter(n => n.title.toLowerCase().includes(search.toLowerCase()));
  }, [customArticles, search]);

  const combinedBisnis = useMemo(() => {
    const customs = customArticles.filter(a => (a.rubrik||'').toLowerCase()==='bisnis');
    const all = [...customs, ...bisnisList];
    if (!search) return all;
    return all.filter(n => n.title.toLowerCase().includes(search.toLowerCase()));
  }, [customArticles, search]);

  const combinedEvents = useMemo(() => [...customEvents, ...eventsSeed], [customEvents]);
  const combinedLapak = useMemo(() => [...customLapak, ...lapakSeed], [customLapak]);
  const combinedKomunitas = useMemo(() => [...customKomunitas, ...komunitasSeed], [customKomunitas]);

  const allArticlesForAdmin = useMemo(() => [...customArticles, ...newsGrid, ...bisnisList, ...Object.values(hobiData).flat(), ...tipsList, heroSide, [heroFeatured]].flat() as Article[], [customArticles]);

  // Category chart data
  const categoryStats = useMemo(() => {
    const cats = ["Otomotif","Tanaman","Ikan","Ayam","Burung","Reptil","Aquascape","Kucing","Anjing","Mancing"];
    return cats.map(c => {
      const count = allArticlesForAdmin.filter(a => (a.cat||'').toLowerCase().includes(c.toLowerCase())).length + (c==='Otomotif'?2:0);
      return { cat:c, count };
    }).sort((a,b)=>b.count-a.count);
  }, [allArticlesForAdmin]);

  // Admin Forms
  const emptyArticle: any = { title:'', cat:'Otomotif', rubrik:'News', komunitas:'', excerpt:'', content:'', img:'', tag:'', status:'Published' };
  const [showArticleForm, setShowArticleForm] = useState(false);
  const [articleForm, setArticleForm] = useState<any>(emptyArticle);
  const [editingArticleId, setEditingArticleId] = useState<number|null>(null);

  const emptyEvent: any = { title:'', date:'', loc:'', komunitas:'', countdown:'', img:'', desc:'', price:'' };
  const [showEventForm, setShowEventForm] = useState(false);
  const [eventForm, setEventForm] = useState<any>(emptyEvent);
  const [editingEventId, setEditingEventId] = useState<number|null>(null);

  const emptyLapak: any = { name:'', price:'', cat:'Tanaman', seller:'', stock:'', loc:'', img:'', desc:'' };
  const [showLapakForm, setShowLapakForm] = useState(false);
  const [lapakForm, setLapakForm] = useState<any>(emptyLapak);
  const [editingLapakId, setEditingLapakId] = useState<number|null>(null);

  const emptyKomunitas: any = { name:'', category:'Otomotif', members:'', location:'', desc:'', status:'Aktif' };
  const [showKomunitasForm, setShowKomunitasForm] = useState(false);
  const [komunitasForm, setKomunitasForm] = useState<any>(emptyKomunitas);
  const [editingKomunitasId, setEditingKomunitasId] = useState<number|null>(null);

  // CRUD Article
  const saveArticle = () => {
    if (!articleForm.title) { alert('Judul wajib diisi'); return; }
    const newArt: Article = {
      id: editingArticleId || Date.now(),
      cat: articleForm.cat,
      title: articleForm.title,
      excerpt: articleForm.excerpt || articleForm.title.slice(0,80),
      content: articleForm.content,
      img: articleForm.img || `https://images.unsplash.com/photo-1495020689067-958852a7765e?w=400&q=80`,
      time: 'Baru saja',
      views: `${Math.floor(Math.random()*2)+1}k`,
      komunitas: articleForm.komunitas || 'Redaksi',
      tag: articleForm.tag,
      rubrik: articleForm.rubrik,
      status: articleForm.status
    };
    if (editingArticleId) {
      setCustomArticles(prev => prev.map(a => a.id===editingArticleId ? newArt : a));
    } else {
      setCustomArticles(prev => [newArt, ...prev]);
    }
    setShowArticleForm(false);
    setArticleForm(emptyArticle);
    setEditingArticleId(null);
  };
  const editArticle = (a: Article) => {
    setArticleForm({ title:a.title, cat:a.cat, rubrik:a.rubrik||'News', komunitas:a.komunitas, excerpt:a.excerpt, content:(a as any).content||a.excerpt, img:a.img, tag:a.tag, status:a.status||'Published' });
    setEditingArticleId(a.id);
    setShowArticleForm(true);
  };
  const deleteArticle = (id:number) => { if(confirm('Hapus artikel ini?')) setCustomArticles(prev=>prev.filter(a=>a.id!==id)); };

  // CRUD Event
  const saveEvent = () => {
    if (!eventForm.title) { alert('Nama event wajib'); return; }
    const newEv: EventItem = { id: editingEventId || Date.now(), title:eventForm.title, date:eventForm.date||'TBD', loc:eventForm.loc||'Jakarta', komunitas:eventForm.komunitas||'Umum', countdown:eventForm.countdown||'SEGERA', img:eventForm.img||'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=200', desc:eventForm.desc, price:eventForm.price };
    if (editingEventId) setCustomEvents(prev=>prev.map(e=>e.id===editingEventId?newEv:e));
    else setCustomEvents(prev=>[newEv, ...prev]);
    setShowEventForm(false); setEventForm(emptyEvent); setEditingEventId(null);
  };
  const editEvent = (e: EventItem) => { setEventForm({ title:e.title, date:e.date, loc:e.loc, komunitas:e.komunitas, countdown:e.countdown, img:e.img, desc:(e as any).desc||'', price:(e as any).price||'' }); setEditingEventId(e.id); setShowEventForm(true); };
  const deleteEvent = (id:number) => { if(confirm('Hapus event?')) setCustomEvents(prev=>prev.filter(e=>e.id!==id)); };

  // CRUD Lapak
  const saveLapak = () => {
    if (!lapakForm.name) { alert('Nama produk wajib'); return; }
    const newP: Product = { id: editingLapakId||Date.now(), name:lapakForm.name, price:lapakForm.price||'Rp 0', cat:lapakForm.cat, loc:lapakForm.loc||'Jakarta', img:lapakForm.img||'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=300', sold:'Terjual 0', seller:lapakForm.seller, stock:lapakForm.stock, desc:lapakForm.desc };
    if (editingLapakId) setCustomLapak(prev=>prev.map(p=>p.id===editingLapakId?newP:p));
    else setCustomLapak(prev=>[newP, ...prev]);
    setShowLapakForm(false); setLapakForm(emptyLapak); setEditingLapakId(null);
  };
  const editLapak = (p: Product) => { setLapakForm({ name:p.name, price:p.price, cat:p.cat, seller:(p as any).seller||'', stock:(p as any).stock||'', loc:p.loc, img:p.img, desc:(p as any).desc||'' }); setEditingLapakId(p.id); setShowLapakForm(true); };
  const deleteLapak = (id:number) => { if(confirm('Hapus produk?')) setCustomLapak(prev=>prev.filter(p=>p.id!==id)); };

  // CRUD Komunitas
  const saveKomunitas = () => {
    if (!komunitasForm.name) { alert('Nama komunitas wajib'); return; }
    const newK: KomunitasData = { id: editingKomunitasId||Date.now(), name:komunitasForm.name, category:komunitasForm.category, members:komunitasForm.members||'0', location:komunitasForm.location||'Indonesia', desc:komunitasForm.desc||'', status:komunitasForm.status||'Aktif' };
    if (editingKomunitasId) setCustomKomunitas(prev=>prev.map(k=>k.id===editingKomunitasId?newK:k));
    else setCustomKomunitas(prev=>[newK, ...prev]);
    setShowKomunitasForm(false); setKomunitasForm(emptyKomunitas); setEditingKomunitasId(null);
  };
  const editKomunitas = (k: KomunitasData) => { setKomunitasForm({ name:k.name, category:k.category, members:k.members, location:k.location, desc:k.desc, status:k.status }); setEditingKomunitasId(k.id); setShowKomunitasForm(true); };
  const deleteKomunitas = (id:number) => { if(confirm('Hapus komunitas?')) setCustomKomunitas(prev=>prev.filter(k=>k.id!==id)); };

  // ===== RENDER ADMIN LOGIN =====
  if (mode==='admin' && !adminLogged) {
    return (
      <div className="min-h-screen bg-[#f6f7fb] flex items-center justify-center p-4 font-sans">
        <style>{`@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Plus+Jakarta+Sans:wght@700;800&display=swap'); *{font-family:Inter,sans-serif} .display{font-family:'Plus Jakarta Sans',Inter,sans-serif}`}</style>
        <div className="w-full max-w-[380px] bg-white rounded-2xl border shadow-[0_8px_30px_rgba(0,0,0,0.08)] p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-[#2563eb] text-white font-extrabold grid place-items-center text-[20px]">I</div>
            <div>
              <div className="font-extrabold text-[18px] display">Infokomunitas<span className="text-[#2563eb]">.id</span> CMS</div>
              <div className="text-[11px] text-zinc-500 font-semibold tracking-widest uppercase">Admin Panel</div>
            </div>
          </div>
          <h2 className="font-extrabold text-[18px] display mb-1">Masuk Admin</h2>
          <p className="text-[12px] text-zinc-500 mb-4">Gunakan <span className="font-bold text-zinc-800">admin / admin</span> untuk demo. Data disimpan di localStorage.</p>
          <div className="space-y-3">
            <div className="relative">
              <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400"/>
              <input value={loginForm.user} onChange={e=>setLoginForm({...loginForm, user:e.target.value})} placeholder="Username" className="w-full h-10 pl-9 pr-3 rounded-full border bg-[#f6f7fb] text-[13px] outline-none focus:border-[#2563eb] focus:ring-2 focus:ring-[#2563eb]/20"/>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400"/>
              <input type="password" value={loginForm.pass} onChange={e=>setLoginForm({...loginForm, pass:e.target.value})} placeholder="Password" className="w-full h-10 pl-9 pr-3 rounded-full border bg-[#f6f7fb] text-[13px] outline-none focus:border-[#2563eb] focus:ring-2 focus:ring-[#2563eb]/20"/>
            </div>
            {loginError && <div className="text-[11px] bg-red-50 text-red-600 border border-red-200 rounded-lg p-2">{loginError}</div>}
            <button onClick={handleLogin} className="w-full h-10 rounded-full bg-[#2563eb] hover:bg-[#1d4ed8] text-white font-bold text-[13px] transition">🔧 MASUK CMS</button>
            <button onClick={()=>setMode('website')} className="w-full h-9 rounded-full border font-bold text-[12px] hover:bg-zinc-50">🌐 Kembali ke Website</button>
            <div className="text-[10px] text-zinc-400 text-center mt-2">CMS full CRUD • Sinkron otomatis ke website mode via localStorage</div>
          </div>
        </div>
      </div>
    );
  }

  // ===== RENDER ADMIN PANEL =====
  if (mode==='admin' && adminLogged) {
    const menu = [
      { id:'Dashboard', label:'Dashboard', icon:LayoutDashboard },
      { id:'Artikel', label:'Kelola Artikel', icon:FileText },
      { id:'Event', label:'Kelola Event', icon:CalendarDays },
      { id:'Lapak', label:'Kelola Lapak', icon:Store },
      { id:'Komunitas', label:'Kelola Komunitas', icon:Users },
      { id:'Pengaturan', label:'Pengaturan', icon:Settings2 },
    ];
    return (
      <div className="min-h-screen bg-[#f6f7fb] text-zinc-900 font-sans flex">
        <style>{`@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap'); *{font-family:Inter,sans-serif} .display{font-family:'Plus Jakarta Sans',Inter,sans-serif}`}</style>

        {/* Sidebar */}
        <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-[240px] bg-[#0f172a] text-white flex flex-col transition-transform ${adminMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
          <div className="h-[64px] flex items-center gap-3 px-5 border-b border-white/10 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-[#2563eb] grid place-items-center font-extrabold">I</div>
            <div>
              <div className="font-extrabold text-[14px] leading-none display">Infokomunitas.id</div>
              <div className="text-[10px] text-white/60 uppercase tracking-widest font-semibold">CMS Admin</div>
            </div>
            <button onClick={()=>setAdminMobileOpen(false)} className="ml-auto lg:hidden w-7 h-7 grid place-items-center rounded-full bg-white/10"><X className="w-4 h-4"/></button>
          </div>
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
            {menu.map(m=>{
              const Icon=m.icon;
              const active=adminPage===m.id;
              return <button key={m.id} onClick={()=>{setAdminPage(m.id); setAdminMobileOpen(false);}} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[12px] font-semibold transition ${active?'bg-[#2563eb] text-white shadow':'text-white/70 hover:bg-white/10 hover:text-white'}`}><Icon className="w-4 h-4"/>{m.label}{m.id==='Artikel' && <span className="ml-auto bg-white/20 text-[10px] px-1.5 py-0.5 rounded-full">{customArticles.length}</span>}</button>
            })}
          </nav>
          <div className="p-3 border-t border-white/10 space-y-2">
            <div className="bg-white/10 rounded-xl p-3">
              <div className="text-[11px] font-bold">Admin Demo</div>
              <div className="text-[10px] text-white/60">admin • superadmin</div>
              <div className="mt-2 h-1.5 bg-white/10 rounded-full overflow-hidden"><div className="h-full w-[78%] bg-[#2563eb]"/></div>
              <div className="text-[9px] text-white/50 mt-1">Storage terpakai 78%</div>
            </div>
            <button onClick={()=>{setMode('website'); setAdminMobileOpen(false);}} className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl bg-white text-zinc-900 text-[12px] font-bold hover:bg-zinc-100"><Eye className="w-4 h-4"/>Kembali ke Website</button>
            <button onClick={handleLogout} className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl bg-red-600 text-white text-[12px] font-bold hover:bg-red-700"><LogOut className="w-4 h-4"/>Keluar</button>
          </div>
        </aside>

        {/* Main */}
        <div className="flex-1 min-w-0 flex flex-col">
          <header className="h-[64px] bg-white border-b flex items-center justify-between px-4 lg:px-6 sticky top-0 z-30">
            <div className="flex items-center gap-3">
              <button onClick={()=>setAdminMobileOpen(true)} className="lg:hidden w-9 h-9 grid place-items-center rounded-full border"><Menu className="w-5 h-5"/></button>
              <h1 className="font-extrabold text-[16px] display flex items-center gap-2">{adminPage==='Dashboard' && <LayoutDashboard className="w-5 h-5 text-[#2563eb]"/>}{adminPage==='Artikel' && <FileText className="w-5 h-5 text-[#2563eb]"/>}{adminPage==='Event' && <CalendarDays className="w-5 h-5 text-[#2563eb]"/>}{adminPage==='Lapak' && <Store className="w-5 h-5 text-[#f97316]"/>}{adminPage==='Komunitas' && <Users className="w-5 h-5 text-[#2563eb]"/>}{adminPage==='Pengaturan' && <Settings2 className="w-5 h-5 text-zinc-500"/>}{adminPage}</h1>
              <span className="hidden md:inline-flex text-[10px] bg-[#f6f7fb] border px-2 py-0.5 rounded-full font-bold text-zinc-500">{new Date().toLocaleDateString('id-ID', { weekday:'long', day:'numeric', month:'long', year:'numeric' })}</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="hidden md:flex items-center gap-2 text-[11px] bg-[#eef2ff] text-[#2563eb] border border-[#2563eb]/20 px-3 py-1 rounded-full font-bold"><div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"/>Live Sync: {customArticles.length} artikel baru</div>
              <div className="w-8 h-8 rounded-full bg-[#2563eb] text-white grid place-items-center font-bold text-[12px]">A</div>
            </div>
          </header>

          <main className="p-4 lg:p-6 space-y-5 bg-[#f6f7fb] min-h-[calc(100vh-64px)]">
            {/* DASHBOARD */}
            {adminPage==='Dashboard' && (
              <>
                <div className="grid grid-cols-12 gap-4">
                  {[
                    { label:'Total Artikel', value: allArticlesForAdmin.length, sub:`+${customArticles.length} baru dari CMS`, icon:FileText, color:'bg-[#2563eb]' },
                    { label:'Total Event', value: combinedEvents.length, sub:`${customEvents.length} event custom`, icon:CalendarDays, color:'bg-[#0f172a]' },
                    { label:'Produk Lapak', value: combinedLapak.length, sub:`${customLapak.length} produk custom`, icon:ShoppingBag, color:'bg-[#f97316]' },
                    { label:'Komunitas Aktif', value: combinedKomunitas.length, sub:'4.2k total terdaftar', icon:Users, color:'bg-emerald-600' },
                  ].map(card=>{
                    const Icon=card.icon;
                    return (
                      <div key={card.label} className="col-span-12 sm:col-span-6 lg:col-span-3 bg-white border rounded-xl p-4 shadow-sm">
                        <div className="flex items-center justify-between">
                          <div className={`w-10 h-10 rounded-xl ${card.color} text-white grid place-items-center`}><Icon className="w-5 h-5"/></div>
                          <span className="text-[10px] font-bold bg-[#f6f7fb] border px-2 py-0.5 rounded-full">Hari ini</span>
                        </div>
                        <div className="mt-3 text-[26px] font-extrabold leading-none display">{card.value}</div>
                        <div className="text-[12px] font-bold mt-1">{card.label}</div>
                        <div className="text-[11px] text-zinc-500 mt-0.5">{card.sub}</div>
                      </div>
                    );
                  })}
                </div>

                <div className="grid grid-cols-12 gap-4">
                  <div className="col-span-12 lg:col-span-8 bg-white border rounded-xl p-4 shadow-sm">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-extrabold text-[13px] display flex items-center gap-2"><BarChart3 className="w-4 h-4 text-[#2563eb]"/>Distribusi Artikel per Kategori</h3>
                      <span className="text-[10px] bg-[#2563eb] text-white px-2 py-0.5 rounded-full font-bold">Update real-time</span>
                    </div>
                    <div className="space-y-2.5">
                      {categoryStats.slice(0,8).map(s=>{
                        const max = Math.max(...categoryStats.map(x=>x.count)) || 1;
                        const pct = Math.round((s.count/max)*100);
                        return (
                          <div key={s.cat} className="flex items-center gap-3">
                            <div className="w-[72px] text-[11px] font-bold">{s.cat}</div>
                            <div className="flex-1 h-2.5 bg-[#f6f7fb] border rounded-full overflow-hidden">
                              <div className="h-full bg-[#2563eb] rounded-full" style={{width:`${pct}%`}}/>
                            </div>
                            <div className="w-[32px] text-[11px] font-bold text-right">{s.count}</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  <div className="col-span-12 lg:col-span-4 bg-white border rounded-xl p-4 shadow-sm">
                    <h3 className="font-extrabold text-[13px] display flex items-center gap-2 mb-3"><Activity className="w-4 h-4 text-emerald-600"/>Aktivitas Terbaru</h3>
                    <div className="space-y-3">
                      {[
                        { act:'Artikel baru ditambahkan', detail: customArticles[0]?.title?.slice(0,40) || 'Belum ada', time:'Baru saja' },
                        { act:'Event dibuat', detail: customEvents[0]?.title?.slice(0,35) || 'Belum ada event custom', time:'2 menit lalu' },
                        { act:'Produk lapak ditambah', detail: customLapak[0]?.name?.slice(0,35) || 'Belum ada produk custom', time:'10 menit lalu' },
                        { act:'Komunitas baru', detail: customKomunitas[0]?.name || 'Bekasi Aquascape Society', time:'1 jam lalu' },
                        { act:'Login admin', detail:'admin • IP 127.0.0.1', time:'2 jam lalu' },
                      ].map((a,i)=>(
                        <div key={i} className="flex gap-2.5 pb-2.5 border-b last:border-0 last:pb-0">
                          <div className="w-1.5 h-1.5 rounded-full bg-[#2563eb] mt-1.5 shrink-0"/>
                          <div className="min-w-0">
                            <div className="text-[11px] font-bold leading-tight">{a.act}</div>
                            <div className="text-[11px] text-zinc-500 truncate">{a.detail}</div>
                            <div className="text-[10px] text-zinc-400">{a.time}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="bg-white border rounded-xl shadow-sm overflow-hidden">
                  <div className="p-4 flex items-center justify-between border-b">
                    <h3 className="font-extrabold text-[13px] display">Artikel Terbaru (dari CMS + dummy)</h3>
                    <button onClick={()=>setAdminPage('Artikel')} className="text-[11px] font-bold text-[#2563eb]">Kelola →</button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-[11px]">
                      <thead className="bg-[#f6f7fb] text-zinc-500 font-bold uppercase text-[10px] tracking-wide">
                        <tr><th className="text-left px-4 py-2">Judul</th><th className="text-left px-3 py-2">Kategori</th><th className="text-left px-3 py-2">Rubrik</th><th className="text-left px-3 py-2">Status</th><th className="text-right px-4 py-2">Aksi</th></tr>
                      </thead>
                      <tbody>
                        {[...customArticles.slice(0,5), ...newsGrid.slice(0,3)].map(a=>(
                          <tr key={a.id} className="border-t hover:bg-[#f8faff]">
                            <td className="px-4 py-2.5"><div className="font-bold line-clamp-1 max-w-[280px]">{a.title}</div><div className="text-[10px] text-zinc-500">{a.komunitas||'Redaksi'}</div></td>
                            <td className="px-3 py-2.5"><span className="bg-zinc-900 text-white px-1.5 py-0.5 rounded text-[10px] font-bold">{a.cat}</span></td>
                            <td className="px-3 py-2.5">{(a as any).rubrik||'News'}</td>
                            <td className="px-3 py-2.5"><span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${((a as any).status||'Published')==='Published'?'bg-green-100 text-green-700':'bg-amber-100 text-amber-700'}`}>{(a as any).status||'Published'}</span></td>
                            <td className="px-4 py-2.5 text-right"><button className="w-6 h-6 rounded-full border grid place-items-center hover:bg-zinc-50"><Eye className="w-3 h-3"/></button></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}

            {/* ARTIKEL */}
            {adminPage==='Artikel' && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3 bg-white border rounded-xl p-3 shadow-sm">
                  <div>
                    <h3 className="font-extrabold text-[14px] display">Kelola Artikel</h3>
                    <p className="text-[11px] text-zinc-500">Data disimpan di <code className="bg-[#f6f7fb] border px-1 rounded">{LS_KEYS.articles}</code> dan langsung tampil di website mode. Dummy + custom digabung.</p>
                  </div>
                  <button onClick={()=>{setArticleForm(emptyArticle); setEditingArticleId(null); setShowArticleForm(true);}} className="h-9 px-4 rounded-full bg-[#2563eb] text-white text-[12px] font-bold flex items-center gap-1.5 hover:bg-[#1d4ed8]"><Plus className="w-4 h-4"/>Tambah Artikel</button>
                </div>

                {showArticleForm && (
                  <div className="bg-white border rounded-xl p-4 shadow-sm space-y-3">
                    <div className="flex items-center justify-between"><h4 className="font-extrabold text-[13px]">{editingArticleId?'Edit':'Tambah'} Artikel</h4><button onClick={()=>{setShowArticleForm(false); setEditingArticleId(null);}} className="w-7 h-7 rounded-full border grid place-items-center"><X className="w-4 h-4"/></button></div>
                    <div className="grid grid-cols-12 gap-3">
                      <div className="col-span-12 lg:col-span-8">
                        <label className="text-[11px] font-bold">Judul* </label>
                        <input value={articleForm.title} onChange={e=>setArticleForm({...articleForm, title:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[13px] outline-none focus:border-[#2563eb]" placeholder="Judul artikel"/>
                      </div>
                      <div className="col-span-6 lg:col-span-2">
                        <label className="text-[11px] font-bold">Kategori</label>
                        <select value={articleForm.cat} onChange={e=>setArticleForm({...articleForm, cat:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-2 text-[12px]"><option>Otomotif</option><option>Tanaman</option><option>Ikan Hias</option><option>Ayam Hias</option><option>Burung</option><option>Reptil</option><option>Aquascape</option><option>Kucing</option><option>Anjing</option><option>Mancing</option><option>News</option><option>Bisnis</option><option>Tips</option></select>
                      </div>
                      <div className="col-span-6 lg:col-span-2">
                        <label className="text-[11px] font-bold">Rubrik</label>
                        <select value={articleForm.rubrik} onChange={e=>setArticleForm({...articleForm, rubrik:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-2 text-[12px]"><option>News</option><option>Bisnis</option><option>Hobi</option><option>Tips</option><option>Rekomendasi</option></select>
                      </div>
                      <div className="col-span-12 lg:col-span-4">
                        <label className="text-[11px] font-bold">Komunitas</label>
                        <input value={articleForm.komunitas} onChange={e=>setArticleForm({...articleForm, komunitas:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]" placeholder="Nama komunitas"/>
                      </div>
                      <div className="col-span-6 lg:col-span-3">
                        <label className="text-[11px] font-bold">Status</label>
                        <select value={articleForm.status} onChange={e=>setArticleForm({...articleForm, status:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-2 text-[12px]"><option>Published</option><option>Draft</option></select>
                      </div>
                      <div className="col-span-6 lg:col-span-5">
                        <label className="text-[11px] font-bold">Gambar URL</label>
                        <input value={articleForm.img} onChange={e=>setArticleForm({...articleForm, img:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]" placeholder="https://..."/>
                      </div>
                      <div className="col-span-12">
                        <label className="text-[11px] font-bold">Deskripsi singkat</label>
                        <textarea value={articleForm.excerpt} onChange={e=>setArticleForm({...articleForm, excerpt:e.target.value})} className="w-full mt-1 min-h-[60px] rounded-xl border bg-[#f6f7fb] p-2.5 text-[12px] outline-none focus:border-[#2563eb]" placeholder="Excerpt untuk listing"/>
                      </div>
                      <div className="col-span-12">
                        <label className="text-[11px] font-bold">Isi artikel (textarea besar)</label>
                        <textarea value={articleForm.content} onChange={e=>setArticleForm({...articleForm, content:e.target.value})} className="w-full mt-1 min-h-[140px] rounded-xl border bg-[#f6f7fb] p-2.5 text-[12px] outline-none focus:border-[#2563eb]" placeholder="Tulis isi lengkap artikel..."/>
                      </div>
                      <div className="col-span-12 lg:col-span-6">
                        <label className="text-[11px] font-bold">Tag</label>
                        <input value={articleForm.tag} onChange={e=>setArticleForm({...articleForm, tag:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]" placeholder="HOT, VIRAL, dll"/>
                      </div>
                    </div>
                    <div className="flex gap-2 justify-end pt-2">
                      <button onClick={()=>{setShowArticleForm(false); setEditingArticleId(null);}} className="h-9 px-4 rounded-full border text-[12px] font-bold">Batal</button>
                      <button onClick={saveArticle} className="h-9 px-5 rounded-full bg-[#2563eb] text-white text-[12px] font-bold">Simpan ke localStorage</button>
                    </div>
                  </div>
                )}

                <div className="bg-white border rounded-xl shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-[11px]">
                      <thead className="bg-[#0f172a] text-white text-[10px] uppercase tracking-wide">
                        <tr><th className="text-left px-4 py-2.5">Judul</th><th className="px-3 py-2.5 text-left">Kategori</th><th className="px-3 py-2.5 text-left">Komunitas</th><th className="px-3 py-2.5 text-left">Rubrik</th><th className="px-3 py-2.5 text-left">Status</th><th className="px-3 py-2.5 text-left">Views</th><th className="px-4 py-2.5 text-right">Aksi</th></tr>
                      </thead>
                      <tbody>
                        {customArticles.length===0 && <tr><td colSpan={7} className="px-4 py-8 text-center text-zinc-500">Belum ada artikel custom. Klik Tambah Artikel. Artikel dummy tetap tampil di website mode.</td></tr>}
                        {customArticles.map(a=>(
                          <tr key={a.id} className="border-t hover:bg-[#f8faff]">
                            <td className="px-4 py-2.5"><div className="font-bold max-w-[260px] truncate">{a.title}</div><div className="text-[10px] text-zinc-500 truncate max-w-[260px]">{a.excerpt}</div></td>
                            <td className="px-3 py-2.5"><span className="bg-[#f6f7fb] border px-1.5 py-0.5 rounded-full font-bold text-[10px]">{a.cat}</span></td>
                            <td className="px-3 py-2.5">{a.komunitas}</td>
                            <td className="px-3 py-2.5"><span className="bg-[#2563eb] text-white px-1.5 py-0.5 rounded text-[10px] font-bold">{(a as any).rubrik||'News'}</span></td>
                            <td className="px-3 py-2.5"><span className={`px-1.5 py-0.5 rounded-full font-bold text-[10px] ${((a as any).status||'Published')==='Published'?'bg-green-100 text-green-700':'bg-amber-100 text-amber-700'}`}>{(a as any).status||'Published'}</span></td>
                            <td className="px-3 py-2.5">{a.views}</td>
                            <td className="px-4 py-2.5 text-right">
                              <div className="flex justify-end gap-1">
                                <button onClick={()=>editArticle(a)} className="w-7 h-7 rounded-full bg-[#2563eb]/10 text-[#2563eb] grid place-items-center hover:bg-[#2563eb] hover:text-white"><Edit3 className="w-3.5 h-3.5"/></button>
                                <button onClick={()=>deleteArticle(a.id)} className="w-7 h-7 rounded-full bg-red-50 text-red-600 grid place-items-center hover:bg-red-600 hover:text-white"><Trash2 className="w-3.5 h-3.5"/></button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* EVENT */}
            {adminPage==='Event' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between bg-white border rounded-xl p-3 shadow-sm">
                  <div><h3 className="font-extrabold text-[14px] display">Kelola Event</h3><p className="text-[11px] text-zinc-500">Key: {LS_KEYS.events} • Sinkron ke Agenda & Event Komunitas</p></div>
                  <button onClick={()=>{setEventForm(emptyEvent); setEditingEventId(null); setShowEventForm(true);}} className="h-9 px-4 rounded-full bg-[#2563eb] text-white text-[12px] font-bold flex items-center gap-1.5"><Plus className="w-4 h-4"/>Tambah Event</button>
                </div>
                {showEventForm && (
                  <div className="bg-white border rounded-xl p-4 shadow-sm space-y-3">
                    <div className="flex justify-between"><h4 className="font-bold text-[13px]">{editingEventId?'Edit':'Tambah'} Event</h4><button onClick={()=>setShowEventForm(false)} className="w-7 h-7 rounded-full border grid place-items-center"><X className="w-4 h-4"/></button></div>
                    <div className="grid grid-cols-12 gap-3">
                      <div className="col-span-12 lg:col-span-6"><label className="text-[11px] font-bold">Nama Event*</label><input value={eventForm.title} onChange={e=>setEventForm({...eventForm,title:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div>
                      <div className="col-span-6 lg:col-span-3"><label className="text-[11px] font-bold">Tanggal</label><input value={eventForm.date} onChange={e=>setEventForm({...eventForm,date:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]" placeholder="15 Des 2025"/></div>
                      <div className="col-span-6 lg:col-span-3"><label className="text-[11px] font-bold">Lokasi</label><input value={eventForm.loc} onChange={e=>setEventForm({...eventForm,loc:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div>
                      <div className="col-span-6 lg:col-span-3"><label className="text-[11px] font-bold">Komunitas</label><input value={eventForm.komunitas} onChange={e=>setEventForm({...eventForm,komunitas:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div>
                      <div className="col-span-6 lg:col-span-3"><label className="text-[11px] font-bold">Countdown</label><input value={eventForm.countdown} onChange={e=>setEventForm({...eventForm,countdown:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]" placeholder="3 HARI LAGI"/></div>
                      <div className="col-span-6 lg:col-span-3"><label className="text-[11px] font-bold">Harga Tiket</label><input value={eventForm.price} onChange={e=>setEventForm({...eventForm,price:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]" placeholder="Rp 50.000 / Gratis"/></div>
                      <div className="col-span-6 lg:col-span-3"><label className="text-[11px] font-bold">Gambar URL</label><input value={eventForm.img} onChange={e=>setEventForm({...eventForm,img:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div>
                      <div className="col-span-12"><label className="text-[11px] font-bold">Deskripsi</label><textarea value={eventForm.desc} onChange={e=>setEventForm({...eventForm,desc:e.target.value})} className="w-full mt-1 min-h-[70px] rounded-xl border bg-[#f6f7fb] p-2.5 text-[12px]"/></div>
                    </div>
                    <div className="flex justify-end gap-2"><button onClick={()=>setShowEventForm(false)} className="h-9 px-4 rounded-full border text-[12px] font-bold">Batal</button><button onClick={saveEvent} className="h-9 px-5 rounded-full bg-[#2563eb] text-white text-[12px] font-bold">Simpan</button></div>
                  </div>
                )}
                <div className="bg-white border rounded-xl shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-[11px]"><thead className="bg-[#0f172a] text-white text-[10px] uppercase"><tr><th className="text-left px-4 py-2.5">Event</th><th className="px-3 py-2.5">Tanggal</th><th className="px-3 py-2.5">Lokasi</th><th className="px-3 py-2.5">Harga</th><th className="px-4 py-2.5 text-right">Aksi</th></tr></thead><tbody>{customEvents.length===0 && <tr><td colSpan={5} className="px-4 py-8 text-center text-zinc-500">Belum ada event custom</td></tr>}{customEvents.map(e=><tr key={e.id} className="border-t hover:bg-[#f8faff]"><td className="px-4 py-2.5"><div className="font-bold">{e.title}</div><div className="text-[10px] text-zinc-500">{e.komunitas} • {e.countdown}</div></td><td className="px-3 py-2.5">{e.date}</td><td className="px-3 py-2.5">{e.loc}</td><td className="px-3 py-2.5">{(e as any).price||'-'}</td><td className="px-4 py-2.5 text-right"><div className="flex justify-end gap-1"><button onClick={()=>editEvent(e)} className="w-7 h-7 rounded-full bg-[#2563eb]/10 text-[#2563eb] grid place-items-center hover:bg-[#2563eb] hover:text-white"><Edit3 className="w-3.5 h-3.5"/></button><button onClick={()=>deleteEvent(e.id)} className="w-7 h-7 rounded-full bg-red-50 text-red-600 grid place-items-center hover:bg-red-600 hover:text-white"><Trash2 className="w-3.5 h-3.5"/></button></div></td></tr>)}</tbody></table>
                  </div>
                </div>
              </div>
            )}

            {/* LAPAK */}
            {adminPage==='Lapak' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between bg-white border rounded-xl p-3 shadow-sm">
                  <div><h3 className="font-extrabold text-[14px] display">Kelola Lapak</h3><p className="text-[11px] text-zinc-500">Key: {LS_KEYS.lapak} • Produk terpercaya komunitas</p></div>
                  <button onClick={()=>{setLapakForm(emptyLapak); setEditingLapakId(null); setShowLapakForm(true);}} className="h-9 px-4 rounded-full bg-[#f97316] text-white text-[12px] font-bold flex items-center gap-1.5"><Plus className="w-4 h-4"/>Tambah Produk</button>
                </div>
                {showLapakForm && (
                  <div className="bg-white border rounded-xl p-4 shadow-sm space-y-3">
                    <div className="flex justify-between"><h4 className="font-bold text-[13px]">{editingLapakId?'Edit':'Tambah'} Produk</h4><button onClick={()=>setShowLapakForm(false)} className="w-7 h-7 rounded-full border grid place-items-center"><X className="w-4 h-4"/></button></div>
                    <div className="grid grid-cols-12 gap-3">
                      <div className="col-span-12 lg:col-span-6"><label className="text-[11px] font-bold">Nama Produk*</label><input value={lapakForm.name} onChange={e=>setLapakForm({...lapakForm,name:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div>
                      <div className="col-span-6 lg:col-span-2"><label className="text-[11px] font-bold">Harga</label><input value={lapakForm.price} onChange={e=>setLapakForm({...lapakForm,price:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]" placeholder="Rp 125.000"/></div>
                      <div className="col-span-6 lg:col-span-2"><label className="text-[11px] font-bold">Kategori</label><select value={lapakForm.cat} onChange={e=>setLapakForm({...lapakForm,cat:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-2 text-[12px]"><option>Tanaman</option><option>Ayam</option><option>Otomotif</option><option>Aquascape</option><option>Ikan</option><option>Burung</option><option>Merchandise</option></select></div>
                      <div className="col-span-6 lg:col-span-2"><label className="text-[11px] font-bold">Stok</label><input value={lapakForm.stock} onChange={e=>setLapakForm({...lapakForm,stock:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div>
                      <div className="col-span-6 lg:col-span-3"><label className="text-[11px] font-bold">Seller</label><input value={lapakForm.seller} onChange={e=>setLapakForm({...lapakForm,seller:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div>
                      <div className="col-span-6 lg:col-span-3"><label className="text-[11px] font-bold">Lokasi</label><input value={lapakForm.loc} onChange={e=>setLapakForm({...lapakForm,loc:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div>
                      <div className="col-span-12 lg:col-span-6"><label className="text-[11px] font-bold">Gambar URL</label><input value={lapakForm.img} onChange={e=>setLapakForm({...lapakForm,img:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div>
                      <div className="col-span-12"><label className="text-[11px] font-bold">Deskripsi</label><textarea value={lapakForm.desc} onChange={e=>setLapakForm({...lapakForm,desc:e.target.value})} className="w-full mt-1 min-h-[60px] rounded-xl border bg-[#f6f7fb] p-2.5 text-[12px]"/></div>
                    </div>
                    <div className="flex justify-end gap-2"><button onClick={()=>setShowLapakForm(false)} className="h-9 px-4 rounded-full border text-[12px] font-bold">Batal</button><button onClick={saveLapak} className="h-9 px-5 rounded-full bg-[#f97316] text-white text-[12px] font-bold">Simpan</button></div>
                  </div>
                )}
                <div className="bg-white border rounded-xl shadow-sm overflow-hidden">
                  <div className="overflow-x-auto"><table className="w-full text-[11px]"><thead className="bg-[#0f172a] text-white text-[10px] uppercase"><tr><th className="text-left px-4 py-2.5">Produk</th><th className="px-3 py-2.5">Harga</th><th className="px-3 py-2.5">Kategori</th><th className="px-3 py-2.5">Seller</th><th className="px-4 py-2.5 text-right">Aksi</th></tr></thead><tbody>{customLapak.length===0 && <tr><td colSpan={5} className="px-4 py-8 text-center text-zinc-500">Belum ada produk custom</td></tr>}{customLapak.map(p=><tr key={p.id} className="border-t hover:bg-[#f8faff]"><td className="px-4 py-2.5"><div className="flex gap-2 items-center"><img src={p.img} className="w-8 h-8 rounded object-cover"/><span className="font-bold truncate max-w-[180px]">{p.name}</span></div></td><td className="px-3 py-2.5 font-bold text-[#f97316]">{p.price}</td><td className="px-3 py-2.5">{p.cat}</td><td className="px-3 py-2.5">{(p as any).seller||'-'}</td><td className="px-4 py-2.5 text-right"><div className="flex justify-end gap-1"><button onClick={()=>editLapak(p)} className="w-7 h-7 rounded-full bg-[#2563eb]/10 text-[#2563eb] grid place-items-center hover:bg-[#2563eb] hover:text-white"><Edit3 className="w-3.5 h-3.5"/></button><button onClick={()=>deleteLapak(p.id)} className="w-7 h-7 rounded-full bg-red-50 text-red-600 grid place-items-center hover:bg-red-600 hover:text-white"><Trash2 className="w-3.5 h-3.5"/></button></div></td></tr>)}</tbody></table></div>
                </div>
              </div>
            )}

            {/* KOMUNITAS */}
            {adminPage==='Komunitas' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between bg-white border rounded-xl p-3 shadow-sm">
                  <div><h3 className="font-extrabold text-[14px] display">Kelola Komunitas</h3><p className="text-[11px] text-zinc-500">Key: {LS_KEYS.komunitas} • 10 kategori komunitas</p></div>
                  <button onClick={()=>{setKomunitasForm(emptyKomunitas); setEditingKomunitasId(null); setShowKomunitasForm(true);}} className="h-9 px-4 rounded-full bg-[#2563eb] text-white text-[12px] font-bold flex items-center gap-1.5"><Plus className="w-4 h-4"/>Tambah Komunitas</button>
                </div>
                {showKomunitasForm && (
                  <div className="bg-white border rounded-xl p-4 shadow-sm space-y-3">
                    <div className="flex justify-between"><h4 className="font-bold text-[13px]">{editingKomunitasId?'Edit':'Tambah'} Komunitas</h4><button onClick={()=>setShowKomunitasForm(false)} className="w-7 h-7 rounded-full border grid place-items-center"><X className="w-4 h-4"/></button></div>
                    <div className="grid grid-cols-12 gap-3">
                      <div className="col-span-12 lg:col-span-6"><label className="text-[11px] font-bold">Nama Komunitas*</label><input value={komunitasForm.name} onChange={e=>setKomunitasForm({...komunitasForm,name:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div>
                      <div className="col-span-6 lg:col-span-3"><label className="text-[11px] font-bold">Kategori</label><select value={komunitasForm.category} onChange={e=>setKomunitasForm({...komunitasForm,category:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-2 text-[12px]"><option>Otomotif</option><option>Tanaman</option><option>Ikan Hias</option><option>Ayam Hias</option><option>Burung</option><option>Reptil</option><option>Aquascape</option><option>Kucing</option><option>Anjing</option><option>Mancing</option></select></div>
                      <div className="col-span-6 lg:col-span-3"><label className="text-[11px] font-bold">Jumlah Anggota</label><input value={komunitasForm.members} onChange={e=>setKomunitasForm({...komunitasForm,members:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]" placeholder="1.2k"/></div>
                      <div className="col-span-6 lg:col-span-3"><label className="text-[11px] font-bold">Lokasi</label><input value={komunitasForm.location} onChange={e=>setKomunitasForm({...komunitasForm,location:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div>
                      <div className="col-span-6 lg:col-span-3"><label className="text-[11px] font-bold">Status</label><select value={komunitasForm.status} onChange={e=>setKomunitasForm({...komunitasForm,status:e.target.value})} className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-2 text-[12px]"><option>Aktif</option><option>Nonaktif</option><option>Pending</option></select></div>
                      <div className="col-span-12 lg:col-span-6"><label className="text-[11px] font-bold">Deskripsi</label><textarea value={komunitasForm.desc} onChange={e=>setKomunitasForm({...komunitasForm,desc:e.target.value})} className="w-full mt-1 min-h-[60px] rounded-xl border bg-[#f6f7fb] p-2.5 text-[12px]"/></div>
                    </div>
                    <div className="flex justify-end gap-2"><button onClick={()=>setShowKomunitasForm(false)} className="h-9 px-4 rounded-full border text-[12px] font-bold">Batal</button><button onClick={saveKomunitas} className="h-9 px-5 rounded-full bg-[#2563eb] text-white text-[12px] font-bold">Simpan</button></div>
                  </div>
                )}
                <div className="bg-white border rounded-xl shadow-sm overflow-hidden">
                  <div className="overflow-x-auto"><table className="w-full text-[11px]"><thead className="bg-[#0f172a] text-white text-[10px] uppercase"><tr><th className="text-left px-4 py-2.5">Komunitas</th><th className="px-3 py-2.5">Kategori</th><th className="px-3 py-2.5">Anggota</th><th className="px-3 py-2.5">Lokasi</th><th className="px-4 py-2.5 text-right">Aksi</th></tr></thead><tbody>{customKomunitas.length===0 && <tr><td colSpan={5} className="px-4 py-8 text-center text-zinc-500">Belum ada komunitas custom. Dummy tetap tampil di website.</td></tr>}{customKomunitas.map(k=><tr key={k.id} className="border-t hover:bg-[#f8faff]"><td className="px-4 py-2.5"><div className="font-bold">{k.name}</div><div className="text-[10px] text-zinc-500 truncate max-w-[200px]">{k.desc}</div></td><td className="px-3 py-2.5">{k.category}</td><td className="px-3 py-2.5">{k.members}</td><td className="px-3 py-2.5">{k.location}</td><td className="px-4 py-2.5 text-right"><div className="flex justify-end gap-1"><button onClick={()=>editKomunitas(k)} className="w-7 h-7 rounded-full bg-[#2563eb]/10 text-[#2563eb] grid place-items-center hover:bg-[#2563eb] hover:text-white"><Edit3 className="w-3.5 h-3.5"/></button><button onClick={()=>deleteKomunitas(k.id)} className="w-7 h-7 rounded-full bg-red-50 text-red-600 grid place-items-center hover:bg-red-600 hover:text-white"><Trash2 className="w-3.5 h-3.5"/></button></div></td></tr>)}</tbody></table></div>
                </div>
              </div>
            )}

            {/* PENGATURAN */}
            {adminPage==='Pengaturan' && (
              <div className="grid grid-cols-12 gap-4">
                <div className="col-span-12 lg:col-span-8 bg-white border rounded-xl p-5 shadow-sm space-y-4">
                  <h3 className="font-extrabold text-[14px] display">Pengaturan Website</h3>
                  <div className="grid grid-cols-12 gap-4">
                    <div className="col-span-12"><label className="text-[11px] font-bold">Nama Website</label><input defaultValue="Infokomunitas.id - Wadahnya Semua Komunitas Indonesia" className="w-full mt-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div>
                    <div className="col-span-12 lg:col-span-6"><label className="text-[11px] font-bold">Warna Utama</label><div className="flex gap-2 mt-1"><div className="w-9 h-9 rounded-full bg-[#2563eb] border"/><input defaultValue="#2563eb" className="flex-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div></div>
                    <div className="col-span-12 lg:col-span-6"><label className="text-[11px] font-bold">Background</label><div className="flex gap-2 mt-1"><div className="w-9 h-9 rounded-full bg-[#f6f7fb] border"/><input defaultValue="#f6f7fb" className="flex-1 h-9 rounded-xl border bg-[#f6f7fb] px-3 text-[12px]"/></div></div>
                    <div className="col-span-12"><label className="text-[11px] font-bold">Deskripsi</label><textarea defaultValue="Wadahnya Semua Komunitas Indonesia. Portal berita, bisnis, hobi, event, dan lapak khusus anak komunitas." className="w-full mt-1 min-h-[80px] rounded-xl border bg-[#f6f7fb] p-2.5 text-[12px]"/></div>
                  </div>
                  <button className="h-9 px-5 rounded-full bg-[#2563eb] text-white text-[12px] font-bold">Simpan Pengaturan</button>
                </div>
                <div className="col-span-12 lg:col-span-4 space-y-4">
                  <div className="bg-[#0f172a] text-white rounded-xl p-4">
                    <h4 className="font-bold text-[13px] mb-3">Storage Info</h4>
                    <div className="space-y-2 text-[11px]">
                      <div className="flex justify-between"><span className="text-white/60">Artikel</span><span className="font-bold">{customArticles.length} item</span></div>
                      <div className="flex justify-between"><span className="text-white/60">Event</span><span className="font-bold">{customEvents.length} item</span></div>
                      <div className="flex justify-between"><span className="text-white/60">Lapak</span><span className="font-bold">{customLapak.length} item</span></div>
                      <div className="flex justify-between"><span className="text-white/60">Komunitas</span><span className="font-bold">{customKomunitas.length} item</span></div>
                      <div className="pt-3 border-t border-white/10 flex gap-2">
                        <button onClick={()=>{ if(confirm('Hapus semua data localStorage?')) { localStorage.clear(); setCustomArticles([]); setCustomEvents([]); setCustomLapak([]); setCustomKomunitas([]); alert('Data dihapus'); } }} className="flex-1 h-8 rounded-full bg-red-600 text-white text-[11px] font-bold">Reset Semua</button>
                        <button onClick={()=>{ setMode('website'); }} className="flex-1 h-8 rounded-full bg-white text-zinc-900 text-[11px] font-bold">Lihat Website</button>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white border rounded-xl p-4 shadow-sm">
                    <h4 className="font-bold text-[12px]">Tips Admin</h4>
                    <ul className="text-[11px] text-zinc-600 mt-2 space-y-1 list-disc ml-4">
                      <li>Semua perubahan langsung tampil di website mode</li>
                      <li>Gunakan URL gambar Unsplash untuk cepat</li>
                      <li>Rubrik menentukan posisi artikel di website</li>
                      <li>Kategori dipakai untuk chart & filter hobi</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

          </main>
        </div>
      </div>
    );
  }

  // ===== RENDER WEBSITE MODE (original rame style) =====
  return (
    <div className="min-h-screen bg-[#f6f7fb] text-zinc-900 font-sans antialiased">
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap'); *{font-family:Inter,sans-serif} h1,h2,h3,.display{font-family:'Plus Jakarta Sans',Inter,sans-serif} html,body{overflow-x:hidden} .no-scrollbar::-webkit-scrollbar{display:none} .no-scrollbar{-ms-overflow-style:none; scrollbar-width:none}`}</style>

      {/* TOP TICKER */}
      <div className="bg-[#0f172a] text-white text-[12px] leading-[1] flex items-center overflow-hidden">
        <div className="bg-[#2563eb] px-3 py-2 font-bold flex items-center gap-2 shrink-0">
          <Flame className="w-3.5 h-3.5" /> BREAKING
        </div>
        <div className="flex-1 overflow-hidden">
          <div className="whitespace-nowrap animate-[marquee_40s_linear_infinite] flex gap-8 py-2 px-4">
            <span>• Kontes Modifikasi Senayan: 800 mobil tumpah ruah, komunitas JDM sapu bersih piala</span>
            <span>• Harga Monstera Var anjlok, petani: ini siklus biasa tiap akhir tahun</span>
            <span>• Piala Kicau Nusantara hadiah 1,2M, daftar hari ini terakhir!</span>
            <span>• Komunitas Vespa touring 1000KM Jawa-Bali sambil baksos</span>
            {customArticles[0] && <span>• BARU CMS: {customArticles[0].title}</span>}
          </div>
        </div>
        <div className="hidden md:flex items-center gap-3 px-4 text-zinc-300">
          <span>Senin, 9 Des 2025</span><span>•</span><span className="text-white">Live: 12.4k online</span>
        </div>
      </div>

      {/* HEADER */}
      <header className="bg-white border-b sticky top-0 z-40 shadow-[0_2px_12px_rgba(0,0,0,0.06)]">
        <div className="max-w-[1280px] mx-auto px-4 lg:px-6">
          <div className="flex items-center justify-between h-[64px] gap-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#2563eb] text-white font-extrabold grid place-items-center text-[18px]">I</div>
              <div className="leading-none">
                <div className="font-extrabold text-[20px] tracking-tight display">Infokomunitas<span className="text-[#2563eb]">.id</span></div>
                <div className="text-[10px] tracking-[0.14em] font-semibold text-zinc-500 uppercase -mt-[1px]">Wadahnya Semua Komunitas Indonesia</div>
              </div>
            </div>

            <nav className="hidden lg:flex items-center gap-1">
              {["News","Bisnis","Hobi","Tips","Agenda","Lapak","Profil","Rekomendasi"].map(n=>{
                const targetId = {News:'news', Bisnis:'bisnis', Hobi:'hobi', Tips:'tips', Agenda:'agenda', Lapak:'lapak', Profil:'profil', Rekomendasi:'rekomendasi'}[n] || n.toLowerCase();
                return (
                <button key={n} onClick={()=>{
                  setActiveNav(n);
                  const el = document.getElementById(targetId);
                  if (el) el.scrollIntoView({behavior:'smooth', block:'start'});
                }}
                  className={`px-3 py-2 rounded-full text-[13px] font-semibold transition ${activeNav===n ? "bg-[#2563eb] text-white" : "hover:bg-zinc-100 text-zinc-700"}`}>
                  {n}
                </button>
                )
              })}
            </nav>

            <div className="flex items-center gap-2">
              {/* TOGGLE WEBSITE / CMS */}
              <div className="hidden md:flex items-center bg-[#f6f7fb] border rounded-full p-1">
                <button onClick={()=>setMode('website')} className={`px-3 py-1.5 rounded-full text-[11px] font-bold flex items-center gap-1 transition ${mode==='website' ? 'bg-[#2563eb] text-white shadow' : 'text-zinc-600 hover:bg-white'}`}>🌐 Website</button>
                <button onClick={()=>setMode('admin')} className={`px-3 py-1.5 rounded-full text-[11px] font-bold flex items-center gap-1 transition ${mode==='admin' ? 'bg-[#2563eb] text-white shadow' : 'text-zinc-600 hover:bg-white'}`}>🔧 Admin CMS</button>
              </div>

              <div className="hidden md:flex items-center gap-2 bg-[#f6f7fb] border rounded-full px-3 h-9 w-[220px] focus-within:ring-2 focus-within:ring-[#2563eb]/20 focus-within:border-[#2563eb]">
                <Search className="w-4 h-4 text-zinc-400"/>
                <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Cari komunitas..." className="bg-transparent outline-none text-[13px] w-full placeholder:text-zinc-400"/>
              </div>
              <button className="hidden md:inline-flex bg-[#f97316] hover:bg-[#ea6a0f] text-white text-[12px] font-bold px-4 h-9 rounded-full">GABUNG KOMUNITAS</button>
              <button onClick={()=>setMobileMenu(!mobileMenu)} className="lg:hidden w-9 h-9 grid place-items-center rounded-full border"><Menu className="w-5 h-5"/></button>
            </div>
          </div>

          {mobileMenu && (
            <div className="lg:hidden pb-4 border-t pt-3 space-y-3">
              <div className="flex items-center gap-2 bg-[#f6f7fb] border rounded-full p-1 w-fit">
                <button onClick={()=>{setMode('website'); setMobileMenu(false);}} className={`px-3 py-1.5 rounded-full text-[11px] font-bold ${mode==='website'?'bg-[#2563eb] text-white':'bg-white border'}`}>🌐 Website</button>
                <button onClick={()=>{setMode('admin'); setMobileMenu(false);}} className={`px-3 py-1.5 rounded-full text-[11px] font-bold ${mode==='admin'?'bg-[#2563eb] text-white':'bg-white border'}`}>🔧 Admin CMS</button>
              </div>
              <div className="flex items-center gap-2 bg-[#f6f7fb] border rounded-full px-3 h-10">
                <Search className="w-4 h-4 text-zinc-400"/>
                <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Cari..." className="bg-transparent outline-none text-[13px] w-full"/>
              </div>
              <div className="flex flex-wrap gap-2">
                {["News","Bisnis","Hobi","Tips","Agenda","Lapak","Profil","Rekomendasi"].map(n=>{
                  const targetId = {News:'news', Bisnis:'bisnis', Hobi:'hobi', Tips:'tips', Agenda:'agenda', Lapak:'lapak', Profil:'profil', Rekomendasi:'rekomendasi'}[n] || n.toLowerCase();
                  return (
                  <button key={n} onClick={()=>{
                    setActiveNav(n); setMobileMenu(false);
                    setTimeout(()=>{ const el=document.getElementById(targetId); if(el) el.scrollIntoView({behavior:'smooth'}); },100);
                  }} className={`px-3 py-1.5 rounded-full text-[12px] font-semibold border ${activeNav===n ? "bg-[#2563eb] text-white border-[#2563eb]" : "bg-white"}`}>{n}</button>
                  )
                })}
              </div>
            </div>
          )}
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <div className="max-w-[1280px] mx-auto px-4 lg:px-6 py-4 lg:py-5 grid grid-cols-12 gap-4 lg:gap-5 overflow-hidden">

        <div className="col-span-12 lg:col-span-8 space-y-5">

          {/* HERO - keep original rame */}
          <section id="profil" className="grid grid-cols-12 gap-3 bg-white rounded-xl border p-3 shadow-sm">
            <div className="col-span-12 lg:col-span-7 group cursor-pointer" onClick={()=>setSelected(heroFeatured)}>
              <div className="relative overflow-hidden rounded-lg aspect-[16/10]">
                <img src={heroFeatured.img} className="w-full h-full object-cover group-hover:scale-[1.03] transition duration-500" alt=""/>
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"/>
                <div className="absolute top-3 left-3 flex gap-2">
                  <span className="bg-[#2563eb] text-white text-[10px] font-bold px-2 py-1 rounded">{heroFeatured.cat}</span>
                  <span className="bg-[#f97316] text-white text-[10px] font-bold px-2 py-1 rounded animate-pulse">{heroFeatured.tag}</span>
                </div>
                <div className="absolute bottom-0 p-4 text-white">
                  <h1 className="text-[20px] lg:text-[24px] font-extrabold leading-[1.15] display line-clamp-3">{heroFeatured.title}</h1>
                  <p className="text-[12px] text-white/80 mt-2 line-clamp-2 hidden lg:block">{heroFeatured.excerpt}</p>
                  <div className="flex items-center gap-2 mt-2 text-[11px] text-white/70">
                    <span className="bg-white/15 px-2 py-0.5 rounded-full">{heroFeatured.komunitas}</span>
                    <span>• {heroFeatured.time}</span><span>• {heroFeatured.views} views</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-span-12 lg:col-span-5 grid grid-rows-4 gap-2 min-w-0">
              {heroSide.map(item=>(
                <div key={item.id} onClick={()=>setSelected(item)} className="flex gap-2.5 p-2 rounded-lg hover:bg-[#f6f7fb] cursor-pointer border border-transparent hover:border-zinc-200 transition group">
                  <img src={item.img} className="w-[88px] h-[66px] rounded-md object-cover shrink-0" alt=""/>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[9px] font-bold tracking-wider px-1.5 py-0.5 rounded bg-zinc-900 text-white">{item.cat}</span>
                      <span className="text-[10px] text-zinc-500">{item.time}</span>
                    </div>
                    <h3 className="text-[12.5px] font-bold leading-[1.25] line-clamp-2 group-hover:text-[#2563eb] mt-1">{item.title}</h3>
                    <div className="text-[10px] text-zinc-500 mt-1 truncate">{item.komunitas}</div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* KATEGORI KOMUNITAS */}
          <section className="bg-white rounded-xl border shadow-sm p-3">
            <div className="flex items-center justify-between mb-2.5">
              <h2 className="font-extrabold text-[14px] flex items-center gap-2 display"><span className="w-1 h-4 bg-[#2563eb] rounded-full inline-block"/>KATEGORI KOMUNITAS</h2>
              <button className="text-[11px] font-semibold text-[#2563eb] flex items-center gap-1">Lihat Semua <ChevronRight className="w-3 h-3"/></button>
            </div>
            <div className="flex gap-2.5 overflow-x-auto no-scrollbar pb-1">
              {kategoriKomunitas.map(k=>{
                const Icon = k.icon;
                return (
                  <div key={k.name} className="shrink-0 w-[108px] border rounded-xl p-2.5 hover:shadow-md hover:border-[#2563eb]/30 cursor-pointer transition bg-[#fcfdff]">
                    <div className={`w-8 h-8 rounded-full grid place-items-center ${k.color} mb-2`}><Icon className="w-4 h-4"/></div>
                    <div className="text-[12px] font-bold leading-tight">{k.name}</div>
                    <div className="text-[10px] text-zinc-500 mt-0.5">{k.count}</div>
                  </div>
                )
              })}
            </div>
          </section>

          {/* NEWS GRID - now with CMS data */}
          <section id="news" className="bg-white rounded-xl border shadow-sm p-3">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-extrabold text-[16px] flex items-center gap-2 display"><span className="bg-[#2563eb] text-white text-[11px] px-2 py-0.5 rounded">NEWS</span> Kabar Komunitas Hari Ini {customArticles.filter(a=>a.rubrik==='News').length>0 && <span className="bg-[#f97316] text-white text-[9px] px-1.5 py-0.5 rounded-full animate-pulse">{customArticles.filter(a=>a.rubrik==='News').length} BARU CMS</span>}</h2>
              <div className="text-[11px] text-zinc-500 flex items-center gap-1"><Clock className="w-3 h-3"/>Update tiap jam</div>
            </div>
            <div className="grid grid-cols-12 gap-3">
              {combinedNews.map(a=>(
                <article key={`news-${a.id}`} onClick={()=>setSelected(a)} className="col-span-12 sm:col-span-6 lg:col-span-4 border rounded-xl overflow-hidden hover:shadow-md cursor-pointer group bg-[#fcfdff] relative">
                  {(a as any).id > 1000 && <span className="absolute top-2 right-2 z-10 bg-[#2563eb] text-white text-[8px] font-bold px-1.5 py-0.5 rounded-full">CMS</span>}
                  <div className="aspect-[16/10] overflow-hidden"><img src={a.img} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" alt=""/></div>
                  <div className="p-2.5">
                    <div className="flex items-center gap-2 text-[10px] text-zinc-500 mb-1"><span className="font-bold text-[#2563eb]">{a.cat}</span>• {a.time}</div>
                    <h3 className="font-bold text-[13px] leading-[1.3] line-clamp-2 group-hover:text-[#2563eb]">{a.title}</h3>
                    <p className="text-[11px] text-zinc-500 line-clamp-2 mt-1">{a.excerpt}</p>
                  </div>
                </article>
              ))}
            </div>
          </section>

          <div className="grid grid-cols-12 gap-4">
            <section id="bisnis" className="col-span-12 lg:col-span-5 bg-white rounded-xl border shadow-sm p-3 min-w-0">
              <h2 className="font-extrabold text-[14px] flex items-center gap-2 mb-3 display"><span className="w-1 h-4 bg-[#f97316] rounded-full"/>BISNIS KOMUNITAS {combinedBisnis.some((a:any)=>a.id>1000) && <span className="text-[9px] bg-[#2563eb] text-white px-1.5 py-0.5 rounded-full">CMS UPDATE</span>}</h2>
              <div className="space-y-2.5">
                {combinedBisnis.map(b=>(
                  <div key={`bisnis-${b.id}`} onClick={()=>setSelected(b)} className="flex gap-2.5 p-2 rounded-lg border hover:border-[#2563eb]/30 hover:bg-[#f8faff] cursor-pointer">
                    <img src={b.img} className="w-[72px] h-[72px] rounded-lg object-cover shrink-0" alt=""/>
                    <div className="min-w-0">
                      <div className="text-[10px] font-bold text-[#f97316]">{b.komunitas}</div>
                      <h4 className="text-[12px] font-bold leading-[1.3] line-clamp-2">{b.title}</h4>
                      <div className="text-[10px] text-zinc-500 mt-1 line-clamp-1">{b.excerpt}</div>
                      <div className="text-[10px] text-zinc-400 mt-1">{b.time} • {b.views} baca</div>
                    </div>
                  </div>
                ))}
              </div>
              <button className="w-full mt-3 h-8 rounded-full border text-[12px] font-semibold hover:bg-zinc-50 flex items-center justify-center gap-1">Lihat Peluang Bisnis Lain <ArrowUpRight className="w-3 h-3"/></button>
            </section>

            <section id="hobi" className="col-span-12 lg:col-span-7 bg-white rounded-xl border shadow-sm p-3 min-w-0">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-extrabold text-[14px] flex items-center gap-2 display"><span className="w-1 h-4 bg-[#2563eb] rounded-full"/>HOBI & KOLEKSI</h2>
                <div className="flex gap-1 bg-[#f6f7fb] p-1 rounded-full border">
                  {Object.keys(hobiData).map(k=>(
                    <button key={k} onClick={()=>setActiveHobi(k)} className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${activeHobi===k?"bg-[#2563eb] text-white shadow":"text-zinc-600 hover:bg-white"}`}>{k}</button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-12 gap-2.5">
                {[...customArticles.filter(a=>a.rubrik==='Hobi' && a.cat.toLowerCase().includes(activeHobi.toLowerCase())), ...hobiData[activeHobi]].map(a=>(
                  <div key={`hobi-${a.id}`} onClick={()=>setSelected(a)} className="col-span-12 sm:col-span-6 lg:col-span-4 border rounded-xl overflow-hidden cursor-pointer hover:shadow">
                    <img src={a.img} className="aspect-[16/10] w-full object-cover" alt=""/>
                    <div className="p-2">
                      <div className="text-[10px] text-zinc-500">{a.time} • {a.views} lihat</div>
                      <h4 className="text-[12px] font-bold leading-[1.3] line-clamp-2 mt-1">{a.title}</h4>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <section id="tips" className="bg-gradient-to-br from-[#eef2ff] to-white rounded-xl border shadow-sm p-3">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-full bg-[#2563eb] text-white grid place-items-center"><Star className="w-4 h-4"/></div>
              <h2 className="font-extrabold text-[14px] display">TIPS & TRIK - DARI PAKAR KOMUNITAS</h2>
              <span className="ml-auto text-[10px] bg-amber-300 text-amber-900 font-bold px-2 py-0.5 rounded-full">CURATED</span>
            </div>
            <div className="grid grid-cols-12 gap-2.5">
              {[...customArticles.filter(a=>a.rubrik==='Tips'), ...tipsList].map(t=>(
                <div key={`tips-${t.id}`} onClick={()=>setSelected(t)} className="col-span-12 sm:col-span-6 lg:col-span-3 bg-white border rounded-xl overflow-hidden cursor-pointer hover:shadow">
                  <img src={t.img} className="aspect-[16/10] w-full object-cover" alt=""/>
                  <div className="p-2.5">
                    <div className="inline-flex text-[9px] font-bold bg-[#2563eb] text-white px-1.5 py-0.5 rounded">TIPS</div>
                    <h4 className="text-[12px] font-bold leading-[1.3] mt-1 line-clamp-2">{t.title}</h4>
                    <p className="text-[11px] text-zinc-500 line-clamp-2 mt-1">{t.excerpt}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section id="agenda" className="bg-white rounded-xl border shadow-sm p-3">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-extrabold text-[14px] flex items-center gap-2 display"><Calendar className="w-4 h-4 text-[#2563eb]"/>AGENDA & EVENT KOMUNITAS {customEvents.length>0 && <span className="text-[9px] bg-[#2563eb] text-white px-1.5 py-0.5 rounded-full">{customEvents.length} BARU</span>}</h2>
              <button onClick={()=>setMode('admin')} className="text-[11px] font-bold text-[#2563eb] border border-[#2563eb]/20 px-3 py-1 rounded-full hover:bg-[#2563eb] hover:text-white transition">+ Buat Event</button>
            </div>
            <div className="grid grid-cols-12 gap-2.5">
              {combinedEvents.map(ev=>(
                <div key={`ev-${ev.id}`} className="col-span-12 sm:col-span-6 lg:col-span-12 xl:col-span-6 flex gap-2.5 border rounded-xl p-2.5 hover:shadow-sm bg-[#fcfdff]">
                  <img src={ev.img} className="w-[84px] h-[84px] rounded-lg object-cover shrink-0" alt=""/>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[9px] font-bold bg-red-600 text-white px-1.5 py-0.5 rounded animate-pulse">{ev.countdown}</span>
                      <span className="text-[10px] bg-zinc-900 text-white px-1.5 py-0.5 rounded-full">{ev.komunitas}</span>
                      {(ev as any).id>1000 && <span className="text-[8px] bg-[#2563eb] text-white px-1 py-0.5 rounded-full">CMS</span>}
                    </div>
                    <h4 className="text-[12px] font-bold leading-[1.3] line-clamp-2">{ev.title}</h4>
                    <div className="flex items-center gap-3 mt-1 text-[11px] text-zinc-500">
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3"/>{ev.date}</span>
                      <span className="flex items-center gap-1"><MapPin className="w-3 h-3"/>{ev.loc}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section id="lapak" className="bg-white rounded-xl border shadow-sm p-3">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-extrabold text-[14px] flex items-center gap-2 display"><ShoppingBag className="w-4 h-4 text-[#f97316]"/>LAPAK KOMUNITAS <span className="text-[10px] font-semibold bg-[#f97316] text-white px-2 py-0.5 rounded-full">TERPERCAYA</span> {customLapak.length>0 && <span className="text-[9px] bg-[#2563eb] text-white px-1.5 py-0.5 rounded-full">{customLapak.length} BARU CMS</span>}</h2>
              <button className="text-[11px] font-bold flex items-center gap-1">Lihat Semua <ChevronRight className="w-3 h-3"/></button>
            </div>
            <div className="grid grid-cols-12 gap-2.5">
              {combinedLapak.map(p=>(
                <div key={`lapak-${p.id}`} className="col-span-6 sm:col-span-3 border rounded-xl overflow-hidden hover:shadow-md transition bg-white group relative">
                  {(p as any).id>1000 && <span className="absolute top-2 right-2 z-10 bg-[#2563eb] text-white text-[8px] font-bold px-1 py-0.5 rounded-full">CMS</span>}
                  <div className="relative aspect-square overflow-hidden bg-[#f6f7fb]">
                    <img src={p.img} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" alt=""/>
                    <span className="absolute top-2 left-2 text-[9px] font-bold bg-white/90 backdrop-blur border px-1.5 py-0.5 rounded-full">{p.cat}</span>
                  </div>
                  <div className="p-2">
                    <h4 className="text-[11.5px] font-semibold leading-[1.3] line-clamp-2 min-h-[30px]">{p.name}</h4>
                    <div className="text-[13px] font-extrabold text-[#f97316] mt-1">{p.price}</div>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-[10px] text-zinc-500">{p.sold}</span>
                      <span className="text-[10px] text-zinc-500 flex items-center gap-0.5"><MapPin className="w-2.5 h-2.5"/>{p.loc}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <div className="grid grid-cols-12 gap-4">
            <section id="rekomendasi" className="col-span-12 lg:col-span-6 bg-white rounded-xl border shadow-sm p-3">
              <h2 className="font-extrabold text-[14px] flex items-center gap-2 mb-3 display"><Users className="w-4 h-4 text-[#2563eb]"/>PROFIL KOMUNITAS MINGGU INI</h2>
              <div className="flex gap-3 border rounded-xl p-3 bg-gradient-to-br from-[#eef2ff] to-white">
                <img src="https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200" className="w-[72px] h-[72px] rounded-xl object-cover" alt=""/>
                <div className="min-w-0">
                  <div className="text-[11px] font-bold text-[#2563eb]">KOMUNITAS PILIHAN EDITOR</div>
                  <h3 className="font-extrabold text-[14px] leading-tight">Bekasi Aquascape Society</h3>
                  <p className="text-[11px] text-zinc-600 mt-1 line-clamp-2">Berawal dari 5 orang hobi aquascape di garasi, sekarang 800+ member aktif, punya galeri dan workshop rutin tiap minggu. Juara 2 Iwagumi nasional.</p>
                  <div className="flex gap-2 mt-2">
                    <span className="text-[10px] bg-zinc-900 text-white px-2 py-0.5 rounded-full">842 Anggota</span>
                    <span className="text-[10px] border px-2 py-0.5 rounded-full">Bekasi</span>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 mt-2.5">
                {["Galeri Karya","Workshop Rutin","Jual Beli Trusted"].map(t=>(
                  <div key={t} className="border rounded-lg p-2 text-center bg-[#f6f7fb]">
                    <div className="text-[11px] font-bold">{t}</div>
                    <div className="text-[10px] text-zinc-500">Aktif</div>
                  </div>
                ))}
              </div>
            </section>

            <section className="col-span-12 lg:col-span-6 bg-white rounded-xl border shadow-sm p-3">
              <h2 className="font-extrabold text-[14px] flex items-center gap-2 mb-3 display"><Star className="w-4 h-4 text-amber-500"/>REKOMENDASI TEMPAT NONGKRONG</h2>
              <div className="space-y-2">
                {[
                  { name:"Kopi Kebun - Pasar Minggu", cat:"Basecamp Komunitas Tanaman", rating:"4.8", img:"https://images.unsplash.com/photo-1445116572660-236099ec97a0?w=200" },
                  { name:"Bengkel Kolektif - Bandung", cat:"Markas Anak Custom", rating:"4.9", img:"https://images.unsplash.com/photo-1558981852-426c6c22a060?w=200" },
                  { name:"Aquascape Cafe - Malang", cat:"Nongkrong Sambil Lihat Tank", rating:"4.7", img:"https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=200" },
                ].map(r=>(
                  <div key={r.name} className="flex gap-2.5 border rounded-xl p-2 hover:bg-[#f6f7fb]">
                    <img src={r.img} className="w-[64px] h-[64px] rounded-lg object-cover" alt=""/>
                    <div>
                      <h4 className="text-[12px] font-bold leading-tight">{r.name}</h4>
                      <div className="text-[11px] text-zinc-500">{r.cat}</div>
                      <div className="flex items-center gap-1 mt-1"><Star className="w-3 h-3 fill-amber-400 text-amber-400"/><span className="text-[11px] font-bold">{r.rating}</span><span className="text-[10px] text-zinc-500">(312 review komunitas)</span></div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>
        </div>

        <aside className="col-span-12 lg:col-span-4 space-y-4 lg:sticky lg:top-[72px] self-start min-w-0">
          <div className="bg-white rounded-xl border shadow-sm p-3">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-full bg-red-600 text-white grid place-items-center"><TrendingUp className="w-4 h-4"/></div>
              <h3 className="font-extrabold text-[13px] display">TRENDING HARI INI</h3>
              <span className="ml-auto text-[10px] font-bold bg-red-100 text-red-600 px-2 py-0.5 rounded-full">LIVE</span>
            </div>
            <div className="space-y-2.5">
              {trending.map(t=>(
                <div key={t.rank} onClick={()=>setSelected({ id:100+t.rank, cat:"Trending", title:t.title, excerpt:"Artikel trending dari komunitas, banyak dibahas di grup WA dan Facebook.", img:"https://images.unsplash.com/photo-1495020689067-958852a7765e?w=200", time:"Trending", views:t.views } as any)} className="flex gap-2.5 cursor-pointer group">
                  <div className="text-[28px] font-extrabold leading-none text-zinc-200 group-hover:text-[#2563eb]">{t.rank}</div>
                  <div className="min-w-0 border-b pb-2.5 flex-1">
                    <h4 className="text-[12px] font-bold leading-[1.3] line-clamp-2 group-hover:text-[#2563eb]">{t.title}</h4>
                    <div className="text-[10px] text-zinc-500 mt-1">{t.views} dibaca • 2 jam lalu</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-[#0f172a] text-white rounded-xl p-3 shadow-sm">
            <h3 className="font-extrabold text-[13px] flex items-center gap-2 mb-3"><Calendar className="w-4 h-4 text-[#f97316]"/>EVENT TERDEKAT</h3>
            <div className="space-y-2.5">
              {combinedEvents.slice(0,3).map(ev=>(
                <div key={`side-${ev.id}`} className="bg-white/10 rounded-lg p-2.5 flex gap-2.5">
                  <div className="w-10 h-10 rounded-lg bg-white text-zinc-900 grid place-items-center font-extrabold text-[12px] leading-none">{ev.date.split(" ")[0]}<br/><span className="text-[9px] font-bold">{ev.date.split(" ")[1]}</span></div>
                  <div className="min-w-0">
                    <div className="text-[11px] font-bold leading-tight line-clamp-1">{ev.title}</div>
                    <div className="text-[10px] text-white/70">{ev.loc}</div>
                    <div className="text-[9px] bg-[#f97316] inline-block px-1.5 py-0.5 rounded font-bold mt-1">{ev.countdown}</div>
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full mt-3 bg-white text-zinc-900 h-8 rounded-full text-[12px] font-bold">Lihat Kalender Lengkap</button>
          </div>

          <div className="bg-white rounded-xl border shadow-sm p-3">
            <h3 className="font-extrabold text-[13px] flex items-center gap-2 mb-3"><ShoppingBag className="w-4 h-4 text-[#f97316]"/>LAPAK TERLARIS MINGGU INI</h3>
            <div className="space-y-2">
              {combinedLapak.slice(0,4).map(p=>(
                <div key={`side-lapak-${p.id}`} className="flex gap-2.5">
                  <img src={p.img} className="w-[48px] h-[48px] rounded-lg object-cover" alt=""/>
                  <div className="min-w-0 flex-1">
                    <div className="text-[11px] font-semibold line-clamp-1">{p.name}</div>
                    <div className="text-[11px] font-bold text-[#f97316]">{p.price}</div>
                    <div className="text-[10px] text-zinc-500">{p.sold} • {p.loc}</div>
                  </div>
                  <button className="self-center w-6 h-6 rounded-full border grid place-items-center hover:bg-[#f6f7fb]"><ChevronRight className="w-3 h-3"/></button>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-xl p-4 bg-gradient-to-br from-[#2563eb] to-[#1d4ed8] text-white relative overflow-hidden">
            <div className="absolute -right-6 -top-6 w-28 h-28 bg-white/15 rounded-full blur-[1px]"/>
            <div className="relative">
              <div className="text-[12px] font-bold bg-white/20 inline-block px-2 py-0.5 rounded-full">UNTUK ANAK KOMUNITAS</div>
              <h3 className="font-extrabold text-[16px] leading-tight mt-2 display">Punya Komunitas? Daftarkan di Infokomunitas.id Gratis!</h3>
              <p className="text-[11px] text-white/80 mt-1">Dapat halaman profil, lapak, dan publikasi event. Sudah 4.2k komunitas bergabung.</p>
              <button onClick={()=>setMode('admin')} className="mt-3 bg-white text-[#2563eb] text-[12px] font-extrabold px-4 h-8 rounded-full">🔧 BUKA CMS ADMIN</button>
              <div className="mt-2 text-[10px] text-white/70">{customArticles.length} artikel • {customEvents.length} event • {customLapak.length} produk dari CMS-mu sudah live</div>
            </div>
          </div>

          <div className="bg-white rounded-xl border p-3">
            <h4 className="font-bold text-[12px]">Dapatkan Info Komunitas Tiap Pagi</h4>
            <div className="flex gap-1.5 mt-2">
              <input placeholder="Email kamu" className="flex-1 border rounded-full px-3 h-8 text-[12px] outline-none focus:border-[#2563eb]"/>
              <button className="bg-[#2563eb] text-white px-4 h-8 rounded-full text-[11px] font-bold">LANGGANAN</button>
            </div>
            <div className="text-[10px] text-zinc-500 mt-2">Gratis, bisa berhenti kapan saja. 12k+ sudah berlangganan.</div>
          </div>
        </aside>
      </div>

      <footer className="bg-[#0f172a] text-zinc-300 mt-6">
        <div className="max-w-[1280px] mx-auto px-4 lg:px-6 py-8 grid grid-cols-12 gap-6">
          <div className="col-span-12 lg:col-span-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded bg-[#2563eb] text-white grid place-items-center font-extrabold">I</div>
              <div className="font-extrabold text-white text-[18px]">Infokomunitas<span className="text-[#60a5fa]">.id</span></div>
            </div>
            <div className="text-[12px] mt-2 leading-relaxed text-zinc-400">Wadahnya Semua Komunitas Indonesia. Portal berita, bisnis, hobi, event, dan lapak khusus anak komunitas. Dari otomotif, tanaman, ikan, ayam, burung, reptil, sampai aquascape. CMS: data tersimpan di localStorage {LS_KEYS.articles}.</div>
            <div className="flex gap-2 mt-4">
              {["FB","IG","YT","TT"].map(s=>(
                <div key={s} className="w-8 h-8 rounded-full bg-white/10 grid place-items-center text-[11px] font-bold hover:bg-white hover:text-zinc-900 cursor-pointer transition">{s}</div>
              ))}
            </div>
          </div>
          {[
            { title:"Kategori", links:["Otomotif","Tanaman Hias","Ikan Hias","Ayam Hias","Burung Kicau","Reptil","Aquascape","Kucing & Anjing"] },
            { title:"Layanan", links:["Berita Komunitas","Bisnis Komunitas","Lapak Jual Beli","Agenda Event","Profil Komunitas","Tips & Trik","Rekomendasi Tempat"] },
            { title:"Perusahaan", links:["Tentang Infokomunitas.id","Kontak Redaksi","Pedoman Media","Karir","Media Kit","Daftarkan Komunitasmu"] },
          ].map(col=>(
            <div key={col.title} className="col-span-6 lg:col-span-2">
              <h4 className="text-white font-bold text-[12px] tracking-wide uppercase mb-3">{col.title}</h4>
              <div className="space-y-2">
                {col.links.map(l=>(<div key={l} className="text-[12px] hover:text-white cursor-pointer">{l}</div>))}
              </div>
            </div>
          ))}
        </div>
        <div className="border-t border-white/10">
          <div className="max-w-[1280px] mx-auto px-4 lg:px-6 py-3 flex flex-col md:flex-row gap-2 justify-between text-[11px] text-zinc-500">
            <span>© 2025 Infokomunitas.id - Wadahnya Semua Komunitas Indonesia. All rights reserved.</span>
            <span className="flex gap-3"><span>Syarat & Ketentuan</span><span>Kebijakan Privasi</span><span>Disclaimer</span><button onClick={()=>setMode('admin')} className="text-[#60a5fa] font-bold hover:underline">🔧 Admin CMS</button></span>
          </div>
        </div>
      </footer>

      {selected && (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm p-4 grid place-items-center overflow-y-auto">
          <div className="bg-white max-w-[680px] w-full rounded-2xl overflow-hidden shadow-2xl relative max-h-[90vh] flex flex-col">
            <button onClick={()=>setSelected(null)} className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/60 text-white grid place-items-center hover:bg-black z-10"><X className="w-4 h-4"/></button>
            <img src={selected.img} className="w-full aspect-[16/9] object-cover" alt=""/>
            <div className="p-5 overflow-y-auto">
              <div className="flex items-center gap-2 mb-2">
                <span className="bg-[#2563eb] text-white text-[10px] font-bold px-2 py-0.5 rounded">{selected.cat}</span>
                <span className="text-[11px] text-zinc-500">{selected.time} • {selected.views} views</span>
                {(selected as any).rubrik && <span className="text-[10px] bg-[#f6f7fb] border px-2 py-0.5 rounded-full font-bold">{(selected as any).rubrik}</span>}
              </div>
              <h2 className="text-[20px] font-extrabold leading-[1.25] display">{selected.title}</h2>
              <div className="text-[12px] text-zinc-500 mt-2 flex items-center gap-2"><span className="bg-zinc-100 px-2 py-0.5 rounded-full">Sumber: {selected.komunitas || "Redaksi Infokomunitas.id"}</span></div>
              <div className="prose prose-sm mt-4 text-[13px] leading-relaxed text-zinc-700">
                <p>Jakarta - {selected.excerpt || (selected as any).content || "Komunitas di Indonesia terus menunjukkan geliat yang luar biasa. Tidak hanya sekadar hobi, tapi sudah menjadi ekosistem bisnis dan silaturahmi yang kuat."}</p>
                {(selected as any).content && (selected as any).content!==selected.excerpt && <p className="mt-3 whitespace-pre-wrap">{(selected as any).content}</p>}
                <p className="mt-3">Menurut pantauan Infokomunitas.id, antusiasme anak komunitas tahun ini naik 40% dibanding tahun lalu. Banyak event kolaborasi antar komunitas yang lahir, dari otomotif sampai tanaman hias.</p>
                <p className="mt-3">Ketua pelaksana event mengatakan, "Ini bukti kalau komunitas di Indonesia itu solid. Bukan cuma kumpul-kumpul, tapi ada value edukasi, bisnis, dan sosialnya. Di Infokomunitas.id kita wadahi semua."</p>
                <p className="mt-3">Bagi kamu yang ingin bergabung atau mempublikasikan kegiatan komunitasmu, bisa langsung daftar gratis di Infokomunitas.id. Sudah lebih dari 4.200 komunitas yang bergabung dan mendapatkan exposure hingga 2 juta pembaca per bulan.</p>
                <div className="mt-4 p-3 bg-[#f6f7fb] border rounded-xl text-[11px]">
                  <div className="font-bold">Diskusi Komunitas:</div>
                  <div className="mt-1 space-y-1 text-zinc-600">
                    <div>• @budi_modif: "Gokil acaranya rame pol, next bikin di Surabaya dong min!"</div>
                    <div>• @tanaman_sultan: "Info bibitnya dong, mau join"</div>
                    <div>• @kicaumania_jkt: "Hadiahnya beneran 1,2M? Mantap"</div>
                  </div>
                </div>
              </div>
              <div className="flex gap-2 mt-5">
                <button onClick={()=>setSelected(null)} className="flex-1 h-9 rounded-full bg-[#2563eb] text-white font-bold text-[12px]">TUTUP</button>
                <button className="flex-1 h-9 rounded-full border font-bold text-[12px]">SHARE KE GRUP WA</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <style>{`@keyframes marquee{0%{transform:translateX(0)}100%{transform:translateX(-50%)}} .scrollbar-none::-webkit-scrollbar{display:none} .scrollbar-none{ -ms-overflow-style:none; scrollbar-width:none }`}</style>
    </div>
  );
}
